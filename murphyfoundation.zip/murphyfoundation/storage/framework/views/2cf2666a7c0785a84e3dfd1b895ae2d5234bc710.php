<style>

body{
            margin: 0;
            padding: 0;
            background:linear-gradient(rgba(0, 0, 0, 0.995),rgba(8, 8, 8, 0.863)),url('img/sus1.webp') no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            overflow-x: hidden;
            height: 100%;
            width: 100%;
            color: antiquewhite;
            font-family: 'Grenze', serif;
        }
        
         .btn.btn-success{
            color:#454242;
            border-radius: 25px;
            background: transparent;
            margin-bottom: 100px;
        }
        #myBtn {
                    display: none;
                    position: fixed;
                    bottom: 20px;
                    right: 30px;
                    z-index: 99;
                    font-size: 18px;
                    border: none;
                    outline: none;
                    color: white;
                    cursor: pointer;
                    padding: 15px;
                    border-radius: 4px;
                }
                
                #myBtn:hover {
                    background-color: #555;
                }
   a{
        text-decoration: none;
     }   
     .row.act .col-sm-4 .panel-body p{
        font-size:16px;
     }
.row.act .col-sm-4 .panel-body{
      border: none;
      background:#000;
      padding-bottom: 30px;
      height: 380px;
      color: antiquewhite;
  }
  .row.act .col-sm-4 .panel-default{
      border: none;
      width: 370px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }
.row.act .col-sm-4 .panel-default.bd .panel-body{
    background: rgb(240, 243, 245);
     color: green;
     background-size: cover;
     background-position: center;
  }
  .row.act .col-sm-4 .panel-default.habitat .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act .col-sm-4 .panel-default.A-for .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act{
     padding-right: 20px;

  }        
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 100;
    color: aliceblue;
    font-size: 15px;
    
}
.fa-instagram{
    font: 100;
    color: aliceblue;
    font-size: 15px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}

.fa-github{
    color: rgb(0, 0, 0);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}
      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 25px;
      }
       
       
nav.navbar-default{
    padding:0; margin:0;
    background-color: transparent;
    border: none;
}
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 20px;
    margin-top:0;
}
.jumbotron h1{
    color: antiquewhite;
    font-weight: bolder;
}
footer{
        background-color:rgb(26, 26, 26);
        margin:0 36px;
        color: aliceblue;
        padding-top:20px;
        padding-right:20px; 
        padding-left:30px;
    }
    footer h3{
        font-size: 18px;
    }
    footer p{
        color:  rgb(141, 139, 139);
    }
      
.container{
    box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
    color: #454242;
    background:#fefdfd;

}
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:15px;
          color: aliceblue;
        }
        .container.top span.float{
          float:right;
        }
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
 
        footer{padding-top:50px; padding-right:0px; padding-left:0px;margin: 0 11px;} 
        footer .col-sm-12{
            padding: 0;
            margin: 0;
        }
        .row.act .col-sm-4 .panel-default{
      border: none;
      width: 310px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }

        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:10px;
        }
        .container.top span.float{
          float:right;
          font-size: 18px;
        }          
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 10;
    color: aliceblue;
    font-size: 12px;
    
}
.fa-instagram{
    font: 10;
    color: aliceblue;
    font-size: 12px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 10;
    font-size: 12px;
    color: aliceblue;
}

      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 15px;
      }
  .row.act{
     padding-right: 20px;
     padding-left: 20px;

  } 
  span.stelar{
      font-size: 13px;
  }  
    h2.top{
      font-size: 29px;
    }  
    p.top{
      font-size: 15px;
    }
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 0px;
    margin-top:0;
    padding-top: 50px;
}
.container{
    box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
    color: #454242;
    background:#fefdfd;
    padding: 0;
    margin: 0;
    width: 100%;

}


}
</style>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
        <div class="jumbotron">
            
            <h2 class="text-center top"style="color:#454242;">
              Murphy Charitable Foundation
            </h2>
          <p class="text-center top"style="color:#666464;">
              Changing the world one donation at a time.
          </p>
          </div><!---end div for jumbotron---->
          <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-justify">
                <h3 style="color:#454242;"><strong>Become A Volunteer Today</strong></h3>
                <p>
                    Volunteer in Uganda or South Africa and join us in transforming vulnerable people's lives at murphy charitable foundation. <br>
                    Come with us on mission trip to help support many of our various programs and activities, you can either offer to come as an individual or team to help train, educate communities and provide care to our children or as health team to treat and provide health services to patients at the health facilities, or as a construction team to help build infrastructure ranging from school's, children homes, medical centers, water supply systems,or as a mission team to evangelise and educate our children and community at large about God and many values.
                   
                </p>
                <h6>Kindly fill the form below to register your interest and we will get back to you in no time.</h6>
                
                    <?php echo Form::open(['action' => 'VolunteerFormController@store','method' => 'post']); ?>

                       <div class="form-group">
                           <?php echo e(Form::text('name', '', [ 'class' => 'form-control', 'placeholder' => 'Your full name.....', 'required'])); ?>

                       </div>
                       <div class="form-group">
                           <?php echo e(Form::text('email', '', [ 'class' => 'form-control', 'placeholder' => 'Your email.....', 'required'])); ?>

                       </div>
                       <div class="form-group">
                           <?php echo e(Form::number('number', '', [ 'class' => 'form-control', 'placeholder' => 'Your phone number.....', 'required'])); ?>

                       </div>
                       <div class="form-group">
                           <?php echo e(Form::text('country', '', [ 'class' => 'form-control', 'placeholder' => 'Your country.....', 'required'])); ?>

                       </div>
                       <div class="form-group">
                           <?php echo e(Form::text('gender', '', [ 'class' => 'form-control', 'placeholder' => 'The gender you identify as.....', 'required'])); ?>

                       </div>
                       <?php echo csrf_field(); ?>
                       <?php echo e(Form::submit('Volunteer', ['class' => 'btn btn-success btn-md pull-right', 'style' => 'text-transform:uppercase;'])); ?>

                    <?php echo Form::close(); ?>

                   </div>
               </div>
            </div>
        </div>
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/pages/volunteer.blade.php ENDPATH**/ ?>