@extends('layouts.app')
<style>

body{
            margin: 0;
            padding: 0;
            background:linear-gradient(rgba(0, 0, 0, 0.995),rgba(8, 8, 8, 0.863)),url('img/sus1.webp') no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            overflow-x: hidden;
            height: 100%;
            width: 100%;
            color: antiquewhite;
            font-family: 'Grenze', serif;
        }
        
        .btn.btn-success{
            border-radius: 25px;
            background: transparent;
            margin-bottom: 100px;
            color:#454242;
        }
        #myBtn {
                    display: none;
                    position: fixed;
                    bottom: 20px;
                    right: 30px;
                    z-index: 99;
                    font-size: 18px;
                    border: none;
                    outline: none;
                    color: white;
                    cursor: pointer;
                    padding: 15px;
                    border-radius: 4px;
                }
                
                #myBtn:hover {
                    background-color: #555;
                }
                /*Gallery*/
    .container.gallery .mySlides img{
        height: 300px;
    }
    .container.gallery img.demo{
        height: 100px;
    }
    .row.bottom{
        padding-left:15px;
        padding-right:15px;
    }            
* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

/* Position the image container (needed to position the left and right arrows) */
.container.gallery {
  position: relative;
  margin-top: 40px;
  margin-bottom: 40px;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #222;
  padding: 2px 16px;
  color: white;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}
/************************************************/

.row.act .col-sm-4 .panel-body{
      border: none;
      background:#000;
      padding-bottom: 30px;
      height: 380px;
      color: antiquewhite;
  }
  .row.act .col-sm-4 .panel-default{
      border: none;
      width: 370px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }
.row.act .col-sm-4 .fa{
     font-size: 85px;
     color: green;
     padding-top: 40px;
 }
.row.act .col-sm-4 .panel-default.bd .panel-body{
    background: rgb(240, 243, 245);
     color: green;
     background-size: cover;
     background-position: center;
  }
  .row.act .col-sm-4 .panel-default.habitat .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act .col-sm-4 .panel-default.A-for .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act{
     padding-right: 20px;

  }
  .col-sm-6.first{
      margin-right: 0;
      padding-right: 0;
  }
  .col-sm-6.first .panel-default{
    margin-right:0px; 
    margin-left:110px;
  }
  .col-sm-6.last{
      margin-left: 0;
      padding-left: 0;
  }
  
  .row.help .panel-default .panel-body{
    background: rgb(240, 243, 245);
     color: green;
      height: 350px;
      margin-right: 0;
      width: 450px;
      margin-bottom: 40px;
  }
  .row.help .panel-default .panel-body.img{
            background:url('img/help.webp') no-repeat;
            background-size: cover;
            margin-left: 0;
            background-position: center;
  }
   a{
        text-decoration: none;
     }           
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    font: 100;
    color: aliceblue;
    font-size: 15px;
    
}
.fa-instagram,
.fa-whatsapp{
    font: 100;
    color: aliceblue;
    font-size: 15px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}

.fa-github{
    color: rgb(0, 0, 0);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}
      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 25px;
      }
       
       
nav.navbar-default{
    padding:0; margin:0;
    background-color: transparent;
    border: none;
}
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 20px;
    margin-top:0;
}
.jumbotron h1{
    color: antiquewhite;
    font-weight: bolder;
}
footer{
        background-color:rgb(26, 26, 26);
        margin:0 36px;
        color: aliceblue;
        padding-top:20px;
        padding-right:20px; 
        padding-left:30px;
    }
    footer h3{
        font-size: 18px;
    }
    footer p{
        color:  rgb(141, 139, 139);
    }
        .col-sm-9,.col-sm-3{
            padding-top: 90px;
            font-family: 'Grenze', serif;
        }
        .col-sm-3 img{
            width:100px;
            height: 50px;
        }
        .col-sm-5{padding-right:200px;}

        .container{
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
            color:#666464;
            background:#FEFDFD;
        }
        .container.top{
          color: aliceblue;
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:15px;
        }
        .container.top span.float{
          float:right;
        }
@media only screen and (max-width: 768px) {
  /* For mobile phones: */
 
        .col-sm-9,.col-sm-3{
            padding-top: 10px;
            font-family: 'Grenze', serif;
        }
        .col-sm-5{padding-right:0px;}
        footer{padding-top:50px; padding-right:0px; padding-left:0px;margin: 0 11px;} 
        footer .col-sm-12{
            padding: 0;
            margin: 0;
        }
        
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:10px;
        }
        .container.top span.float{
          float:right;
          font-size: 18px;
        }          
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 10;
    color: aliceblue;
    font-size: 12px;
    
}
.fa-instagram{
    font: 10;
    color: aliceblue;
    font-size: 12px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 10;
    font-size: 12px;
    color: aliceblue;
}

      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 15px;
      }
    h2.top{
      font-size: 29px;
    }  
    p.top{
      font-size: 15px;
    }
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 0px;
    margin-top:0;
    padding-top: 50px;
}

.container{
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
            color:#666464;
            background:#FEFDFD;
            padding: 0;
            margin: 0;
            width: 100%;

}
.col-sm-12.box{
  margin-top: 100px;
}
  .col-sm-6.last{
      margin-left: 0;
      padding-left: 0;
  }
  .col-sm-6.first .panel-default{
    margin-left:0px;
    padding-left: 0;
    margin-bottom: 0;
    padding-bottom: 0;
  }
  .col-sm-6.first{
      margin-right: 0;
      padding-right: 0;
      margin-left: 0;
      padding-left: 0;
  }
  .row.help .panel-default .panel-body{
    background: rgb(240, 243, 245);
     color: green;
      height: 350px;
      margin-right: 0;
      width: 360px;
      margin-bottom: 0px;
      margin-left: 20px;
  }
  .row.help .panel-default .panel-body.img{
            background:url('img/help.webp') no-repeat;
            background-size: cover;
            margin-left: 0;
            margin-left: 20px;
            background-position: center;
  }
}
</style>

@section('content')
@include('inc.top')
<div class="container">
        <div class="jumbotron">
            
            <h2 class="text-center top"style="color:#454242;">
              Murphy Charitable Foundation
            </h2>
          <p class="text-center top"style="color:#666464;">
              Changing the world one donation at a time.
          </p>
          </div><!---end div for jumbotron---->
          @include('inc.nav')
    </div>
<div id="about" class="container text-center">
        <div class="row">
          <div class="col-sm-12">
            <br><br><h2 class="text-justify" style="color:#454242;">About Us</h2> 
            <h3 class="text-justify" style="line-height:1.8em; font-size:3em;color:#454242;">Who We Are</h3>
            <p class="text-justify" style="padding-right:20px; padding-left:20px;">
              Murphy charitable foundation is a registered non-governmental, 
              humanitarian organization established on May-05-2018 in Uganda and in South Africa
               that seeks to implement viable, effective and innovative solutions to pressing
                community crisis and causes. We are operating on the level of local communities in
                 Uganda, meaning we plan and carry out boosts on the ground projects to a accomplish
                  our objectives. Our core work stems from the ideology of providing sustainable, 
                  unique and effective solutions to local communities ongoing problems in sectors 
                  such as vulnerable child education, poverty reduction, gender and equality, 
                  community awareness on climate, reproductive health and nutrition. 
                  With integrity as the foundation of our organization, murphy charitable 
                  foundation Uganda believes that economic prosperity and betterment of humanity
                   is possible through passion, collaboration and innovation, and this requires a 
                   great deal to careful planning, communication and local involvement to accomplish
                    each objective.

            </p>
            <div class="container">
                  <div class="row">
                    <div class="col-sm-12 text-justify">
                      <h4 style="color:#454242;"><strong>Our Mission</strong></h4><br>
                        <p style="text-align: justify">
                            To contribute to the improvement of vulnerable young people lives through educating them, reduction of child mortality, counselling, promoting gender equality and empowerment,
                            promotion of global partnerships for development and community 
                            sensitization with a mission to build a positive mine in every person and end extreme poverty and violence in the families.
                        </p>
                      <p style="color:#454242;"><strong>Our Vision</strong><br> 
                       <i style="text-align: justify">
                          Murphy charitable foundation has a target of reducing human 
                          vulnerability and suffering in the country to 10% and our expected 
                          impact is to raise up poor people standards of living in their communities to 90%.
                          Our main target group of beneficiaries are; helpless orphans, 
                          widows, disabled and, older persons,
                          youths and persons living with sexually transmitted diseases.
                       </i>
                      </div>
                  </div>
                
              </div>
            <div class="box">
              <h3 class="text-justify" style="line-height:1.8em; font-size:3em;color:#454242;">What We Do</h3>
              <p style="padding-top:0px; padding-right:0px; padding-left:0px; text-align:justify;">
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Address gender issues and empower women socially, economically and politically.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Supply of drugs to the needy health centers, setting up schools and health centers in needy communities.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Promote value based education and rights among children, youths, adults at family and community levels for universal development</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Increase awareness about health, sanitation and hygiene in general, STDs and HIV/AIDS in particular.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Promote peace, Interfaith dialogue and bring Sustainable relief services to Internally Displaced persons and disadvantaged persons caused by natural disasters, wars and other pandemics</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Alleviate poverty and strengthen livelihood of the poor and underprivileged communities through promoting sustainable agriculture, climate smart crops, entrepreneurship and agripreneurship, thereby ensuring food security, food sovereignty, nutritional security and income security</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Address and reduce ecological degradation through, conservation of biodiversity, waste management, promotion of renewable energy and, enhancing local climate adaptation methods through mass awareness campaigns, advocacy and research and , plantations of forest species</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Constructing homes for the homeless.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Counselling and guiding young people.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Putting God first in all things.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Support community initiative groups.</li> 
                      <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Supplying of fresh clean water and electricity to the rural areas.</li> 
                </p>
                <h6 style="font-style:oblique: text-transform:capitalize; font-weight:bold;">
                        "THE ONLY WAY FORWARD IS WORKING TOGETHER IN THE LIGHT OF OUR FATHER GOD,AND SEEING IMPORTANCE OF LIFE FOR EVERY LIVING PERSON..."
                        
                </h6><br>
                
<h2 class="text-justify" style="color:#454242;">How We Help</h2>
<p style="text-align: justify">It Starts With the Will to Make a Difference.</p>
<!---div for act---->
<div class="row act">
    
        <div class="col-sm-4 text-center">
                <div class="panel-group">
                   <div class="panel-default habitat first">
                      <div class="panel-body">
                          <p><i class="fa fa-quote-left"></i><i class="fa fa-quote-right"></i></p>
                        <h4>
                                Abundance of life.
                        </h4>
                    </div>
                    </div>
                </div>
              </div>
              <div class="col-sm-4 text-center">
                      <div class="panel-group">
                         <div class="panel-default bd">
                            <div class="panel-body">
                                    <p><i class="fa fa-pied-piper-alt"></i></p>
                              <h4>
                                    Life changing and making a difference.
                             </h4>
                                </div>
                          </div>
                      </div>
                    </div>
                    <div class="col-sm-4 text-center">
                          <div class="panel-group">
                             <div class="panel-default A-for last">
                                <div class="panel-body">
                                        <p><i class="fa fa-paw"></i></p>   
                                  <h4>
                                        Donations & assistance.
                                  </h4>
                                </div>
                              </div>
                          </div>
                    </div>
</div><!---end div for act---->

    <div class="row help">
            <div class="col-sm-6 first">
                
                <div class="panel-group">
                  <div class="panel-default">
                     <div class="panel-body" style="padding:50px;">  
                        <h5 style="padding-top:50px;">
                                "Act as if what you do makes a difference. It does"
                        </h5>
                        <p style="padding-top:20px;">William James</p>
                     </div>
                  </div>
                </div>
            </div>
             <div class="col-sm-6 last">
                    <div class="panel-group">
                        <div class="panel-default" style="margin-left:0px;">
                               <div class="panel-body img">
                               </div>
                       </div>
                   </div>
               </div>
    </div>
</div>
               <a href="contact" class="btn btn-success btn-lg">Get In Touch</a>
            </div>
          </div>

          </div>
        </div>
    <!-----
  <div class="jumbotron text-center col-sm-12">
        <h1>Subscribe to our monthly newsletter.</h1> 
        <p>We bring you latest developments in GIS around the World.</p> 
        <form>
          <div class="input-group">
            <input type="email" class="form-control" size="20" placeholder="Email Address" required>
            <div class="input-group-btn">
              <button type="button" class="btn btn-danger">Subscribe</button>
            </div>
          </div>
        </form>
      </div>
      ------>
        @include('inc.footer')
@endsection