<style>
    a.btn-primary,
    a.btn-info{
        background: #272E4F;
    }
    a.btn-primary:hover,
    a.btn-info:hover{
        background: transparent;
        color: #272E4F;
    }
    .pull-right{
        margin-left: 0;
    }
    .col-sm-4 img{
        height:350px;
        width:350px;
    }
 .row.jumbotron-fluid{
    font-family: 'Grenze', serif;
        width: 100%;
        color:antiquewhite;
        background:linear-gradient(rgba(0, 0, 0, 0.9),rgba(8, 8, 8, 0.863)), url('img/trr.jpg') no-repeat;
        background-size: cover;
        background-position: top;
        background-attachment:fixed;
        height: 600px;
        margin: 0;
        padding: 20px 0 20px 0;
        }
    .jumbotron-fluid h1{
        padding-top: 150px;
        font-weight: bolder;
        text-align: center;
        margin-left:60px;
        color:antiquewhite; 
        font-weight:bold; 
        line-height:1.5em; 
        font-size:30px;
        }
.row.main{
        background-color:rgb(26, 26, 26);
        height: 390px;
        background:linear-gradient(rgba(0, 0, 0, 1),rgba(8, 8, 8, 0.863)), url('../img/priest2.jpg') no-repeat;
        background-size: cover;
        background-position: center;
        background-attachment:fixed;
        text-align: center;
    }
    .navbar.navbar-expand-md{
        background-color:transparent; 
        margin-bottom:0px;
    }
    
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
  
  .jumbotron-fluid h1{
        padding-top: 50px;
        font-weight: bold;
        text-align: center;
        margin-left:0px;
        font-size: 19px;
        }
        h2{
            font-weight: 15px;
        }
.row.main{
    height: 250px;
}
.col-sm-4 img{
        height:280px;
        width:280px;
    }
}
</style>
<?php $__env->startSection('content'); ?>
<div class="row main">
    <div class="jumbotron-fluid">
        <h1 class="text-center"><?php echo $post->title; ?></h1>
    </div>
</div>
<hr>
<div class="container bo" style="margin-top:80px;">
  
<!--Since the result isnt stored in an array, no need to loop-->
    <h2 style="color:#000;"><?php echo e($post->title); ?></h2>
    <small>Written on <?php echo e($post->created_at); ?></small>
   
<?php if(!Auth::guest()): ?>
<!-----If user is not a guest and is the owner of the post show the edit and delete buttons---->

    <?php if(Auth::user()->id == $post->user_id): ?>

        <a href="../Posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary btn-sm" title="Edit Article"><i class="fa fa-edit"></i></a>
            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger btn-sm'])); ?>

            <?php echo Form::close(); ?>

            
        
    <?php endif; ?>
<?php endif; ?>
    <hr>
    <div class="row">
    <div class="col-sm-8" style="padding-bottom:20px; text-align:justify;">
           <?php echo $post->body; ?>

    </div>
    <div class="col-sm-4" style="padding-bottom:20px; text-align:justify;">
            <img src="../storage/img/<?php echo e($post->cover_image); ?>" class="img-responsive" alt="">
    </div>
    
</div>
<br><br><a href="../Posts" class="btn btn-info btn-md pull-left" style="margin-top:20px;margin-bottom:300px;">Back</a>
<a href="" class="btn pull-right btn-lg">
        <i class="fa fa-envelope"></i><i class="fa fa-paperclip"></i> <i class="fa fa-print"></i>   
    </a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StPaul\resources\views/posts/show.blade.php ENDPATH**/ ?>