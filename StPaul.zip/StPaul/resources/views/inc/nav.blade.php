

<style>
    .navbar-nav.navbar-nav.ml-auto{
        margin-left: 0px;
       padding-left: 0;
       padding-right: 150px;
       margin-top: 0;
       padding-top: 0;
    }
    a.navbar-brand img{
      margin-top: 0;
      padding-top: 0px;
      height: 50px;
      padding-bottom: 10px;
    }
    a.navbar-brand{
      padding-top: 10px;
      padding-left: 50px;
    }
    .navbar-toggler-icon{
      font-weight: bold;
     padding-right: 15px;
     border: none;
      
    }
    
    .fa.fa-list{
        color: #272E4F;
        font-weight: bold;
    }
    .navbar-nav.ml-auto .nav-item a{
      color: #272E4F;
      font-size: 17px;
      font-weight: bold;
      padding-top: 0px;
      padding-right: 20px;
      font-family:'Courier New', Courier, monospace;
    }
    
    .navbar-nav.ml-auto .nav-item .dropdown-menu a.dropdown-item{
      color: #000;
      padding-top: 0;
    }
    .fixed-top{
      padding-top:0px;
      margin-top: 0;
      
    }
    nav.navbar.navbar-expand-md.fixed-top.scrolled{
      margin-top: 0;
      padding-top: 0px;
      background-color:rgba(0, 0, 0, 0.69);
    }
    li.nav-item.dropdown.pad,
    li.nav-item.pad{
      padding-left: 50px;
    }
    .dropdown:hover .dropdown-menu{
      display: block;
    }
      .fixed-top{
        padding-top: 0; 
        
      }
    p.bar{
        text-transform: uppercase;
        color: #272E4F;
        font-weight: bold;
        font-family: 'Grenze', serif;
        font-size: 15px;
        
    }
    p.bar small{
      
      font-family:'Courier New', Courier, monospace;
        font-size: 12px;
        text-transform: capitalize;
        color:#272E4F;
        font-style: italic;
    
    }
    p.bar span.bar2{
      color:#272E4F;
      font-size: 13px;
      text-transform: capitalize;
    }
      nav.navbar.navbar-expand-md.fixed-top{
        padding-top: 0; 
        padding-bottom: 0;
        
      }
    @media only screen and (max-width: 768px) {
    
    .fixed-top a.navbar-brand img{
      margin-top: 0;
      padding-top: 10px;
      height: 95px;
      font-weight: bold;
      padding-bottom: 50px;
      margin-right: 0;
      padding-right: 0;
    }
    .navbar-nav.ml-auto{
        margin-left: 10px;
    }
    li.nav-item.dropdown.pad,
    li.nav-item.pad{
      padding-left: 0px;
    }
    .fixed-top .collapse.navbar-collapse{
        padding-top: 0;
        padding-left: 40px;
    }
      nav.navbar.navbar-expand-md.fixed-top{
        padding-top: 0; 
        background-color:rgba(0, 0, 0, 0.99);
        padding-bottom: 0;
        
      }
    p.bar{
        margin-left: 0;
        font-size: 10px;
        width:58%;
        padding-bottom: 0;
        font-weight: 400;
        font-family: 'Grenze', serif;
    }
    p.bar small{
        color: #272E4F;
        font-size: 9px; 
        line-height: 1.6em;
        padding-left: 0;
        margin-left: 0;
    
    }
    p.bar span.bar2{
     
      font-size: 9px;
      text-transform: capitalize;
    }
    }
    </style>
    
    <nav class="navbar navbar-expand-md fixed-top bg-light">   <!-- Brand -->
        <a class="navbar-brand" href="./"><img src="{{URL::asset('img/p.jpg')}}" alt="" class="img-responsive"></a>
        <p class="bar">Catholic Diocese Of Ekiti <span class="bar2" style="font-style:italic;"><br>St. Paul's Parish</span> <br>
          <small><span style="color:#272E4F;">Ado Road,Afao/Kajola Ikere-Ekiti.</span> <br>P.O Box 95.</small></p>
       
           <!-- Toggler/collapsibe Button -->
           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
             <span class="navbar-toggler-icon fa fa-list"></span>
           </button>
         
           <!-- Navbar links -->
           <div class="collapse navbar-collapse" id="collapsibleNavbar">
             <ul class="navbar-nav ml-auto">
            <li class="nav-item" style="">
                        <a class="nav-link" href="./">Home</a>
             </li>
             <li class="nav-item dropdown">
                  <a class="nav-link" href="#" id="navbardrop" data-toggle="dropdown">
                              Our Parish
                           </a>
                           <div class="dropdown-menu">
                             <a class="dropdown-item" href="about">About Us</a>
                             <a class="dropdown-item" href="team">Contact Us</a>
                             <a class="dropdown-item" href="faq">Parish Administration</a>
                             <a class="dropdown-item" href="faq">Parish Ministries</a>
                           </div>
               </li>
               <li class="nav-item"style="">
                 <a class="nav-link" href="posts">Blog</a>
               </li>
               <!-- Authentication Links -->
               @guest
                   <li class="nav-item pad">
                       <a class="nav-link" href="{{ route('login') }}"><i class="fa fa-user-secret"></i>{{ __('Admin Login') }}</a>
                   </li>
               @else
               
                   <li class="nav-item dropdown pad">
                       <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                           <i class="fa fa-users"></i> <span class="caret"></span>
                       </a>

                       <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="register">
                        {{ __('Add New Admin') }}
                      </a>         
                       <a class="dropdown-item" href="Posts">
                        {{ __('Blog') }}
                      </a>                                       
                     <a class="dropdown-item" href="">
                        {{ __('Check mailbox') }}
                      </a>     
                       <a class="dropdown-item" href="{{ route('home') }}">
                        {{ __('Dashboard') }}
                      </a>         
                      <a class="dropdown-item" href="Posts/create">
                       {{ __('New Article') }}
                     </a>     
                    <a class="dropdown-item" href="{{ route('logout') }}"
                      onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>

                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                    </div>
                   </li>
               @endguest
             </ul>
           </div>
    </nav>
    