<style>

body{
            margin: 0;
            padding: 0;
            background:linear-gradient(rgba(0, 0, 0, 0.995),rgba(8, 8, 8, 0.863)),url('img/sus1.webp') no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            overflow-x: hidden;
            height: 100%;
            width: 100%;
            color: antiquewhite;
            font-family: 'Grenze', serif;
        }
        
        .btn.btn-success{
            background: green;
            border-radius: 25px;
            background: transparent;
            color:#454242;
        } 
        .row.icon .fa{
            font-size: 70px;
            padding-bottom: 40px;
        } 
p.social .fa{
    font-size: 150px;
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
    padding-left: 70px;
}
             
p.social .fa:hover{
    font: normal;
    font-size:100px;
}
        #myBtn {
                    display: none;
                    position: fixed;
                    bottom: 20px;
                    right: 30px;
                    z-index: 99;
                    font-size: 18px;
                    border: none;
                    outline: none;
                    color: white;
                    cursor: pointer;
                    padding: 15px;
                    border-radius: 4px;
                }
                
                #myBtn:hover {
                    background-color: #555;
                }
        .container{
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
            color:#666464;
            background:#FEFDFD;
        }
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:15px;
          color: aliceblue;
        }
        .container.top span.float{
          float:right;
        }
        h3.contact,
        h3.connect{
            padding-top: 100px;
            margin-bottom: 30px;
            padding-left: 50px;
            color:#454242;
        }
 /***Google map**/
 .social .mapouter div.gmap_canvas iframe{
           width:1100px; 
           height: 500px;
           }
            .social .mapouter{
              text-align:right;
              height:500px;
              width:600px;
              }
             .social .gmap_canvas {
                overflow:hidden;
                background:none!important;
                height:500px;
                width:1080px; 
                margin-left: 0;
                padding-left: 0;
         }
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
        h3.contact{
            padding-top: 40px;
            padding-left: 100px;
        }
        
  /***Google map**/
 .social div.mapouter div.gmap_canvas iframe{
           width:320px; 
           height: 400px;
           margin-left: 0px;
           margin-right:0px;
           }
           .social .mapouter{
              text-align:right;
              height:500px;
              width:300px;
              }
             .social .gmap_canvas {
                overflow:hidden;
                background:none!important;
                height:300px;
                width:320px; 
                margin-left: 0;
                padding-left: 0;
                
         }

}
</style>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
    <div class="jumbotron">
        
        <h2 class="text-center top"style="color:#454242;">
          Murphy Charitable Foundation
        </h2>
      <p class="text-center top"style="color:#666464;">
          Changing the world one donation at a time.
      </p>
      </div><!---end div for jumbotron---->
      <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="container">
          
          <h3 class="text-justify contact">Contact Us</h3>
          <div class="row text-center icon">
              <div class="col-sm-3">
                  <p><i class="fa fa-phone" style="color:green;"></i><br>Phone <br>Uganda <br> <small>+256-771983900</small>  <br>South Africa <br><small>0718720829/0817001604</small><br><small>+27845072400/+27787296585</small></p>
              </div>
              <div class="col-sm-3">
                  <p><i class="fa fa-envelope" style="color:green;"></i><br>Email <br><small>murphycharityfoundation.ug@gmail.com</small> <br><small>murphycharity.info@gmail.com</small><br><small>maryannmurphy42@gmail.com</small></p>
              </div>
              <div class="col-sm-3">
                  <p><i class="fa fa-chain" style="color:green;"></i><br>Website Address<br><small>www.murphyfoundation.org</small></p>
              </div>
              <div class="col-sm-3">
                  <p><i class="fa fa-map" style="color:green;"></i><br>Visit Us <br><small>MURPHY CHARITABLE FOUNDATION</small> <br><small>Mbale, Bukedea Uganda.</small>  <br> <small>Middleburg, South-Africa.</small></p>
              </div>
          </div>
          <h3 class="text-justify" style="margin-top:50px;margin-bottom:30px;color:#454242;">Quick Contact</h3>
          <div class="row">
                <div class="col-sm-6 text-justify">
                 <?php echo Form::open(['action' => 'ContactFormController@store','method' => 'post']); ?>

                    <div class="form-group">
                        <?php echo e(Form::text('name', '', [ 'class' => 'form-control', 'placeholder' => 'Your full name.....', 'required'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::text('email', '', [ 'class' => 'form-control', 'placeholder' => 'Your email.....', 'required'])); ?>

                    </div>
                    <div class="form-group">
                        <?php echo e(Form::number('number', '', [ 'class' => 'form-control', 'placeholder' => 'Your phone number.....', 'required'])); ?>

                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group"> 
                        <?php echo e(Form::textarea('message', '', ['class' => 'form-control', 'placeholder' => 'Your Message.....', 'required'])); ?>

                    </div>
                    <?php echo csrf_field(); ?>
                    <?php echo e(Form::submit('Send Message', ['class' => 'btn btn-success btn-md pull-right', 'style' => 'text-transform:uppercase;'])); ?>

                 <?php echo Form::close(); ?>

                </div>
            </div>
          <h3 class="text-justify connect">Connect With Us On Social Media</h3>
          <p class="social">
                <a href="https://www.facebook.com/murphycharityuganda/"> <i class="fa fa-facebook" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;padding-bottom:15px;"></i></a> 
                <a href="https://twitter.com/ugandamurphy"><i class="fa fa-twitter" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;padding-bottom:15px;"></i></a> 
                <a href=""><i class="fa fa-linkedin" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;"></i></a> 
                <a href=""><i class="fa fa-instagram" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;"></i></a> 
                <a href="https://api.whatsapp.com/send?phone=256771983900"><i class="fa fa-whatsapp" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;"></i></a> 
          
          </p>
          <div class="col-sm-12 social">
                <div class="mapouter"><div class="gmap_canvas"><iframe width="476" height="397" id="gmap_canvas" src="https://maps.google.com/maps?q=Bukedea%20district%2Cuganda&t=&z=9&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.enable-javascript.net"></a></div></div>   
        </div>
</div>
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/pages/contact.blade.php ENDPATH**/ ?>