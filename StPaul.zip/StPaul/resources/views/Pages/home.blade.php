@extends('layouts.main')
@include('inc.home')
    @section('content')
    @include('inc.nav')
    <!-------
        <div class="row" style="margin-bottom:400px;">
            
            <video autoplay muted loop width="100%" height="" poster="img/bible1.jpg">
                <source src="img/pope.mp4" type="video/mp4">  
            </video>
        </div>
----->
        <div class="row">
            <div id="demo" class="carousel slide one" data-ride="carousel">
             
                  
                  <!-- Indicators -->
                  <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                    <li data-target="#demo" data-slide-to="3"></li>
                  </ul>
                
                  <!-- The slideshow -->
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img src="{{URL::asset('img/bible1.jpg')}}" alt="bible" style="">
                    </div>
                    <div class="carousel-item">
                      <img src="img/adore2.jpg" alt="Adoration">
                    </div>
                    <div class="carousel-item">
                      <img src="{{URL::asset('img/bible2.jpg')}}" alt="bible2">
                    </div>
                    <div class="carousel-item">
                      <img src="img/adore1.jpg" alt="adoration1">
                    </div>
                  </div>
                  <!-- Left and right controls 
                  <a class="carousel-control-prev" href="#demo" data-slide="prev">
                    <span class="carousel-control-prev-icon"></span>
                  </a>
                  <a class="carousel-control-next" href="#demo" data-slide="next">
                    <span class="carousel-control-next-icon"></span>
                  </a>-->
              </div>
            </div>
        </div>
        <div class="row bl">
            <div class="col-sm-4 first">
                <h1 class="text-center"><i class="fa fa-fire"></i></h1>
                <h2 class="text-justify">Attend Our Masses</h2>
                <p>
                    hiehii hihhdnoj
                    sdshdjdifenjd
                </p>
            </div>
                <div class="col-sm-4">
                   
                    <h4>Sunday Masses</h4>
                    <h5> <i class="fa fa-bank"></i> Our lady of the holy rosary, Fagboun, Ado Road, Ikere-Ekiti.</h5>
                    <p><i class="fa fa-clock-o"></i>7:00AM</p>
                    <h5> <i class="fa fa-bank"></i> Parish Mass</h5>
                    <p><i class="fa fa-clock-o"></i>10:00AM</p>
                </div>
                <div class="col-sm-4">
                    <h4>Weekday Masses</h4>
                    <h5> <i class="fa fa-bank"></i> Parish</h5>
                    <h5>Morning</h5>
                    <p>Tuesdays, Thursdays & Saturdays</p>
                    <p><i class="fa fa-clock-o"></i>5:00AM</p>
                    <h5>Evening</h5>
                    <p>Mondays, Wednesdays & Fridays</p>
                    <p><i class="fa fa-clock-o"></i>5:00PM</p>
                    
                <h5 class="pad"><i class="fa fa-pied-piper-alt"></i><br> There are rosary prayers before every Weekday masses with
                     exposition of the blessed sacrament before every Weekday morning masses..</h5>
                </div>
        </div>
        <div class="row video">
            <div class="col-sm-12 text-center">
                <h4 class="title">Gallery</h4>
                <small><i class="fa fa-long-arrow-left"></i><i class="fa fa-medium"></i><i class="fa fa-long-arrow-right"></i></small>
            </div><br><br><br><br><br>
            <div class="col-sm-6">
            <!-- wrapper -->
            <div class="vplayer" data-v="J1yoQAdHuu0"> 
            
                <!-- play btn -->
                <div class="plybtn"></div> 
                
            </div>
            </div>
            <div class="col-sm-6">
                <h5>The holy eucharist, our treasure</h5>
                <p>
                    We envision sustainable development of communities where everyone is aware of the environmental issues plaguing them and aware of the solutions, have guaranteed opportunities of sustainable development that enables them exercise their rights to food, livelihood, education, 
                    health, peace, while enjoying a life free from economic hardship.
                </p>
            </div>
            <a href="" class="btn btn-default">See More Videos</a>
        </div>
        <div class="row top-0">
            <div class="col-sm-12"style="color:#666464;">
            <!---div for gallery---->
                <div class="row gallery">
                    <div class="container-fluid gallery"id="demo">
                    <div class="mySlides">
                    <img src="img/MD.jpg" style="width:100%">
                    </div>
                
                    <div class="mySlides">
                    <img src="img/MD1.jpg" style="width:100%">
                    </div>
                
                    <div class="mySlides">
                    <img src="img/MD2.jpg" style="width:100%">
                    </div>
                    
                    <div class="mySlides">
                    <img src="img/MD3.jpg" style="width:100%">
                    </div>
                
                    <div class="mySlides">
                    <img src="img/MD4.jpg" style="width:100%">
                    </div>
                    
                    <div class="mySlides">
                    <img src="img/msd.jpg" style="width:100%">
                    </div>
                    <div class="mySlides">
                    <img src="img/evangelizer.jpg" style="width:100%">
                    </div>
                
                    <div class="mySlides">
                    <img src="img/hch.jpg" style="width:100%">
                    </div>
                
                    <div class="mySlides">
                    <img src="img/choir2.jpg" style="width:100%">
                    </div>
                    
                    <div class="mySlides">
                    <img src="img/choir1.jpg" style="width:100%">
                    </div>
                
                    <div class="mySlides">
                    <img src="img/choir.jpg" style="width:100%">
                    </div>
                    
                    <div class="mySlides">
                    <img src="img/cw.jpg" style="width:100%">
                    </div>
                    
                    <a class="prev" onclick="plusSlides(-1)" style="color: goldenrod;">&#10094;</a>
                    <a class="next" onclick="plusSlides(1)" style="color: goldenrod;">&#10095;</a>

                    <div class="caption-container">
                    <p id="caption"></p>
                    </div>
                
                    <div class="row bottom">
                    <div class="column" id="demo">
                        <img class="demo cursor" src="img/MD.jpg" style="width:100%" onclick="currentSlide(1)" alt="Our wonderful mothers during mothers day celebration 2018,<br> <i class='fa fa-quote-left'></i>We believe they are home makers and so we celebrate them!<i class='fa fa-quote-right'></i>">
                    </div>
                    <div class="column"id="demo">
                        <img class="demo cursor" src="img/MD1.jpg" style="width:100%" onclick="currentSlide(2)" alt="Our wonderful mothers during mothers day celebration 2018,<br> <i class='fa fa-quote-left'></i>We believe they are home makers and so we celebrate them!<i class='fa fa-quote-right'></i>">
                    </div>
                    <div class="column"id="demo">
                        <img class="demo cursor" src="img/MD2.jpg" style="width:100%" onclick="currentSlide(3)" alt="Our wonderful mothers during mothers day celebration 2018,<br> <i class='fa fa-quote-left'></i>We believe they are home makers and so we celebrate them!<i class='fa fa-quote-right'></i>">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/MD3.jpg" style="width:100%" onclick="currentSlide(4)" alt="Our wonderful mothers during mothers day celebration 2018,<br> <i class='fa fa-quote-left'></i>We believe they are home makers and so we celebrate them!<i class='fa fa-quote-right'></i>">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/MD4.jpg" style="width:100%" onclick="currentSlide(5)" alt="Our wonderful mothers during mothers day celebration 2018,<br> <i class='fa fa-quote-left'></i>We believe they are home makers and so we celebrate them!<i class='fa fa-quote-right'></i>">
                    </div>    
                    <div class="column">
                        <img class="demo cursor" src="img/msd.jpg" style="width:100%" onclick="currentSlide(6)" alt="Our wonderful mothers during mothers day celebration 2017,<br> <i class='fa fa-quote-left'></i>We believe they are home makers and so we celebrate them!<i class='fa fa-quote-right'></i>">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/evangelizer.jpg" style="width:100%" onclick="currentSlide(7)" alt="Our indefatigable parish priest with our evangelizers on their graduation from the school of evangelization Ekiti diocese.">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/hch.jpg" style="width:100%" onclick="currentSlide(8)" alt="Ekiti diocese holy childhood celebration, 2017.">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/choir2.jpg" style="width:100%" onclick="currentSlide(9)" alt="The parish choir at an outing snapshot with our parish priest.">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/choir1.jpg" style="width:100%" onclick="currentSlide(10)" alt="The parish choir">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/choir.jpg" style="width:100%" onclick="currentSlide(11)" alt="The parish choir">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="img/cw.jpg" style="width:100%" onclick="currentSlide(12)" alt="Some catholic women organization memebers presenting @ a parish event">
                    </div>
                    </div>
                </div><!---end div for gallery container---->
                
                </div><!---end div for gallery row---->
    </div>
        </div>
        <div class="row ministry">
            <div class="col-sm-12 text-center">
                <small>Parish Ministries/Socities.</small>
                <h5><i class="fa fa-quote-left"></i>Let us go forward in peace,our eyes upon heaven,the only one goal of our labors.<i class="fa fa-quote-right"></i></h5>
                <small class="pull-right"><i class="fa fa-steam"></i>St. Therese of Lisieux</small><br>
                <p>
                    For your Spiritual growth and soul gratification, here are some
                    of the Ministries you can join.
                </p>
            </div>
            
                <div class="col-sm-3 one">
                    <div class="panel-default">
                        <div class="panel-body text-center">
                            <button class="rounded-circle"><i class="fa fa-cubes"></i></button>
                            <h4 class="text-center">
                                Parish Choir
                            </h4>
                            <div class="text-center pad">
                                <p>Meeting Schedule</p>
                                <p class="text-justify"><i class="fa fa-bank"></i> Parish Premises</p>
                                <p><i class="fa fa-calendar-check-o"></i>Tuesdays, Thursdays & Saturdays</p>
                                <p><i class="fa fa-clock-o"></i>5:00PM</p>
                                        
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel-default">
                        <div class="panel-body text-center">
                            <button class="rounded-circle"><i class="fa fa-cubes"></i></button>
                            <h4 class="text-center">
                                Lectors Society
                            </h4>
                            <div class="text-center pad">
                                <p>Meeting Schedule</p>
                                <p class="text-justify"><i class="fa fa-bank"></i> Parish Premises</p>
                                <p><i class="fa fa-calendar-check-o"></i>Fridays</p>
                                <p><i class="fa fa-clock-o"></i>After evening mass</p>
                                        
                            </div>    

                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel-default">
                        <div class="panel-body text-center">
                            <button class="rounded-circle"><i class="fa fa-cubes"></i></button>
                            <h4 class="text-center">
                                Altar Servers
                            </h4>
                            <div class="text-center pad">
                                <p>Meeting Schedule</p>
                                <p class="text-justify"><i class="fa fa-bank"></i> Parish Premises</p>
                                <p><i class="fa fa-calendar-check-o"></i>Saturdays</p>
                                <p><i class="fa fa-clock-o"></i>3:00PM</p>
                                        
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="panel-default">
                        <div class="panel-body text-center">
                            <button class="rounded-circle"><i class="fa fa-cubes"></i></button>
                            <h4 class="text-center">
                                Church Warders
                            </h4>
                            <div class="text-center pad">
                                <p>Meeting Schedule</p>
                                <p class="text-justify"><i class="fa fa-bank"></i> Parish Premises</p>
                                <p><i class="fa fa-calendar-check-o"></i>Saturdays</p>
                                <p><i class="fa fa-clock-o"></i>5:00PM</p>
                                        
                            </div>
                        </div>
                    </div>
                </div>
                <a href="" class="btn btn-default">See All Societies</a>

        </div>
        <div class="row faith text-center">
            <div class="col-sm-12 text-center">
                <i class="fa fa-th"></i><br>
                <small>Faith Section</small>
                <h4>Here Are Some Resources For Your Growth</h4>
                <p>From the richness of the catholic faith we bring to you some inspiring articles.</p>
            </div>
            <div class="col-sm-4">
                <a href="">
                <div class="panel-default">
                    <div class="panel-title">
                        <img src="img/adore1.jpg" alt="">
                    </div>
                    <div class="panel-body text-justify">
                        <small><i class="fa fa-calendar-o"></i>July 28,2018 <i class="fa fa-code-fork"></i> Rev. Fr. JP</small>
                        <h5>
                            The Eucharist, Our treasure
                        </h5>
                        <p>
                            Even the all-powerful Pointing has no control about 
                            the blind texts
                        </p>    

                    </div>
                </div>
                </a>
            </div>
            <div class="col-sm-4">
                <a href="">
                <div class="panel-default">
                    <div class="panel-title">
                        <img src="img/adore1.jpg" alt="">
                    </div>
                    <div class="panel-body text-justify">
                        <small><i class="fa fa-calendar-o"></i>July 28,2018 <i class="fa fa-code-fork"></i> Rev. Fr. JP</small>
                        <h5>
                            The Eucharist, Our treasure
                        </h5>
                        <p>
                            Even the all-powerful Pointing has no control about 
                            the blind texts
                        </p>    

                    </div>
                </div>
                </a>
            </div>
            <div class="col-sm-4">
                <a href="">
                <div class="panel-default">
                    <div class="panel-title">
                        <img src="img/adore1.jpg" alt="">
                    </div>
                    <div class="panel-body text-justify">
                        <small><i class="fa fa-calendar-o"></i>July 28,2018 <i class="fa fa-code-fork"></i> Rev. Fr. JP</small>
                        <h5>
                            The Eucharist, Our treasure
                        </h5>
                        <p>
                            Even the all-powerful Pointing has no control about 
                            the blind texts
                        </p>    

                    </div>
                </div>
                </a>
            </div>
            <p class="text-center">
            <a href="./posts" class="btn btn-primary">Visit Blog</a>
            </p>
        </div>
        <div class="row council">
            <div class="col-sm-12">
                <h4 class="text-center">Meet The Parish Council Members</h4>
            </div>
    
            
        <div class="col-sm-3">
           
            <div class="img-container">
                <img src="{{ asset('img/adore1.jpg')}}" alt="Avatar" class="image img-responsive">
                <div class="overlay">
                    <p style="padding-top:40px;">
                            <button class="btn btn-info"><a style="color:aliceblue;text-decoration:none;" href="https://facebook.com/kari.jackson.946"><i class="fa fa-facebook"></i></a></button>
                            <button class="btn btn-info"><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="https://api.whatsapp.com/send?phone=256771983900"><i class="fa fa-whatsapp"></i></a></button>
                    </p>
                    <h4>Most Rev. Dr F. F. Ajakaye</h4>
                    <p>Bishop Ekiti Diocese</p>
                </div>
            </div>

    </div>
         
    <div class="col-sm-3">
           
        <div class="img-container">
            <img src="{{ asset('img/adore1.jpg')}}" alt="Avatar" class="image img-responsive">
            <div class="overlay">
                <p style="padding-top:40px;">
                        <button class="btn btn-info"><a style="color:aliceblue;text-decoration:none;" href="https://facebook.com/kari.jackson.946"><i class="fa fa-facebook"></i></a></button>
                        <button class="btn btn-info"><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="https://api.whatsapp.com/send?phone=256771983900"><i class="fa fa-whatsapp"></i></a></button>
                </p>
                <h4>Rev. Fr. JohnPaul Ogundipe</h4>
                <p>Parish Priest</p>
            </div>
        </div>

</div>
<div class="col-sm-3">
   
        <div class="img-container">
            <img src="{{ asset('img/adore1.jpg')}}" alt="Avatar" class="image img-responsive">
            <div class="overlay">
                <p style="padding-top:40px;">
                        <button class="btn btn-info"><a style="color:aliceblue;text-decoration:none;" href="https://facebook.com/kari.jackson.946"><i class="fa fa-facebook"></i></a></button>
                        <button class="btn btn-info"><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="https://api.whatsapp.com/send?phone=256771983900"><i class="fa fa-whatsapp"></i></a></button>
                </p>
                <h4>Mr. Oloko</h4>
                <p>Parish Council Chairman</p>
            </div>
        </div>

</div>
<div class="col-sm-3">
   
        <div class="img-container">
            <img src="{{ asset('img/adore1.jpg')}}" alt="Avatar" class="image img-responsive">
            <div class="overlay">
                <p style="padding-top:40px;">
                        <button class="btn btn-info"><a style="color:aliceblue;text-decoration:none;" href="https://facebook.com/kari.jackson.946"><i class="fa fa-facebook"></i></a></button>
                        <button class="btn btn-info"><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="https://api.whatsapp.com/send?phone=256771983900"><i class="fa fa-whatsapp"></i></a></button>
                </p>
                <h4>Mr. Oloko</h4>
                <p>Parish Council Chairman</p>
            </div>
        </div>

</div>
</div>
        <!----REMEMBER THE SECTION FOR PRAYER REQUESTS---->

        <div class="row prayer">
            <div class="col-sm-12 text-center">
                <i class="fa fa-language"></i><br>
                <small>We will pray with you...</small>
                <h4>Prayer Requests</h4>
                <p>Have any prayer requests?, let us know about it.</p>
                <!-- Trigger the modal with a button -->
                <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Submit a request here</button>
              
            </div>
            <!-- Modal -->
            <div class="modal fade" id="myModal" role="dialog">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    
                  </div>
                  <div class="modal-body">
                    {!! Form::open(['method' => 'POST']) /** The action should be the block of code in the store function in PostsController
                    **/ !!}
                     <div class="form-group">
                             <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
                         {{Form::label('name', 'Name')}}
                         <!--This is the input field with type=text, name=title, value='' since it is a text field, then bootstrap class and then placeholder--->
                         {{Form::text('name', '', [ 'class' => 'form-control', 'placeholder' => 'Your name', 'style' => 'background:transparent;border-radius:0;border:none;'])}}
                     </div>
                     <div class="form-group">
                             <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
                         {{Form::label('request', 'Request')}}
                         <!--This is the input field with type=text, name=title, value='' since it is a text field, then bootstrap class and then placeholder--->
                         {{Form::textarea('request', '', [ 'class' => 'form-control', 'placeholder' => 'Your request', 'style' => 'background:transparent; border-radius:0;border:none;'])}}
                     </div>
                     {{Form::submit('Submit request', ['class' => 'btn btn-success btn-md pull-right', 'style' => 'text-transform:uppercase;'])}}
                    {!! Form::close() !!}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row footer">
            @include('inc.footer')
        </div>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 

        <script>
            //for gallery
      var slideIndex = 1;
      showSlides(slideIndex);
      
      function plusSlides(n) {
        showSlides(slideIndex += n);
      }
      
      function currentSlide(n) {
        showSlides(slideIndex = n);
      }
      
      function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
        captionText.innerHTML = dots[slideIndex-1].alt;
      }
            // When the user scrolls down 20px from the top of the document, show the button
            window.onscroll = function() {scrollFunction()};
            
            function scrollFunction() {
                if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("myBtn").style.display = "block";
                } else {
                document.getElementById("myBtn").style.display = "none";
                }
            }
            
            // When the user clicks on the button, scroll to the top of the document
            function topFunction() {
                document.body.scrollTop = 0;
                document.documentElement.scrollTop = 0;
            }
            //Youtube video
            
            ( function() {

                    var vplayer= document.querySelectorAll( ".vplayer" );

                    for (var i = 0; i < vplayer.length; i++) {
                        console.log(vplayer[i].dataset.v);
                        var source = "https://img.youtube.com/vi/"+ vplayer[i].dataset.v +"/sddefault.jpg";
                        
                        var image = new Image();
                                image.src = source;
                                image.addEventListener( "load", function() {
                                    vplayer[ i ].appendChild( image );
                                }( i ) );
                        
                                vplayer[i].addEventListener( "click", function() {

                                    var iframe = document.createElement( "iframe" );

                                            iframe.setAttribute( "allowfullscreen", "" );
                                            iframe.setAttribute( "frameborder", "0" );
                                            iframe.setAttribute( "src", "https://www.youtube.com/embed/"+ this.dataset.v +"?rel=0&showinfo=0&autoplay=1" );

                                            this.innerHTML = "";
                                            this.appendChild( iframe );
                                } );    
                    };

                    } )();
            </script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    @endsection