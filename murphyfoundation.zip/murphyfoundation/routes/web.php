<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@index');

Route::get('/contact', function () {
    return view('pages.contact');
});
Route::get('/about', function () {
    return view('pages.about');
});
Route::get('/donate', function () {
    return view('pages.donate');
});
Route::get('/newsletter', function () {
    return view('pages.newsletter');
});
Route::get('/volunteer', function () {
    return view('pages.volunteer');
});
Route::get('/sponsor', function () {
    return view('pages.sponsor');
});
Route::get('/partner', function () {
    return view('pages.partner');
});
//For Mail
Route::get('/contact', 'ContactFormController@create');
Route::post('/contact', 'ContactFormController@store');
Route::post('/partner', 'PartnerFormController@store');
Route::post('/sponsor', 'SponsorFormController@store');
Route::post('/volunteer', 'VolunteerFormController@store');