<?php

namespace App\Http\Controllers;

use App\Mail\ContactMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactFormController extends Controller
{
    //
    public function create(){
        return view('pages.contact');
    }
    public function store(){
        
        $data = request()->validate([
            'name' => 'required',
            'number' => 'required',
            'email' => 'required|email',
            'message' => 'required',
        ]);

        //Send mail
           
            Mail::to('aluko798@gmail.com')->send(new ContactMail($data));
          
            return view('pages.contact')->with('message', 'Thanks for your message. We\'ll be in touch');
    }
}

