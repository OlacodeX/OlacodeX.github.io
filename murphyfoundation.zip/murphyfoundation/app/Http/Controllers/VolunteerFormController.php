<?php

namespace App\Http\Controllers;

use App\Mail\VolunteerMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class VolunteerFormController extends Controller
{
    //
    public function create(){
        return view('pages.sponsor');
    }
    public function store(){
        
        $data = request()->validate([
            'name' => 'required',
            'number' => 'required',
            'email' => 'required|email',
            'country' => 'required',
            'gender' => 'required',
        ]);

        //Send mail
           
            Mail::to('aluko798@gmail.com')->send(new VolunteerMail($data));
          
            return view('pages.volunteer')->with('message', 'Thanks for your message. We\'ll be in touch');
    }
}

