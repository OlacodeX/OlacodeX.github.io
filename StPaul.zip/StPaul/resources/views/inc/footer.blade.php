<style>
    .row.footer{
        margin-top: 0;
        padding-top: 0;
    }
footer{
    background: #272E4F;
    color: gainsboro;
}

footer div.row{
    padding: 100px 40px 40px 60px;
}
footer .col-sm-3 .fa{
  padding: 7px;
  font-size: 15px;
  text-align: center;
  text-decoration: none;
  color:  rgb(141, 139, 139);
}
footer .col-sm-3 .fa-facebook{
  font-size: 13px;
}
footer .col-sm-3 .btn.btn-info{
 border-radius: 100%;
 color:  rgb(141, 139, 139); 
 padding: 7px;
  background:rgba(141, 139, 139, 0.178);
  margin-right: 10px;
  border: none;
}
footer .col-sm-3 .btn.btn-info:hover{
 border-radius: 100%;
 color:  rgb(141, 139, 139); 
 padding: 15px;
  background:rgba(141, 139, 139, 0.178);
  margin-right: 10px;
  border: none;
}
footer .col-sm-3 .btn.btn-primary{
            font-weight: bold;
            font-size: 20px;
            padding: 20px 20px;
            background: transparent;
            border: #272E4F 1px solid;
            color: antiquewhite;
        }
        footer .col-sm-3 .btn.btn-primary:hover{
            background: antiquewhite;
            color:#272E4F;
            padding: 20px 30px;
        }
footer .col-sm-3 ul li{
list-style: none;
}
footer .col-sm-3 ul{
padding-left: 0;
padding-right: 100px;
}
footer .col-sm-3 ul li a{
text-decoration: none;
color:rgba(241, 238, 238, 0.712);
font-weight: bold;
}
.col-sm-5 p{
    padding-right: 50px;
}
footer img{
      margin-top: 0;
      padding-top: 0px;
      height: 250px;
      width:400px;
      padding-bottom: 30px;
    }
    footer a,
    footer a:hover{
        color: gainsboro;
    }
</style>
<footer>
    <div class="row">    
        <div class="col-sm-5">
                <h3 class="text-justify">ABOUT US</h3>
                <img src="{!! URL::asset('img/p.jpg')!!}" class="img-responsive" alt="">
               
                <p class="text-justify">
                  Inspired by a life-changing event, Murphy Charitable Foundation was established in 2018 in South Africa (Africa, SA). Over the years, we have become one of the most trusted and effective charitable foundations as we are guided by our Father God, Over the years we have seen too much pain and heartache.
                  Our core work stems from the ideology of providing sustainable, 
                      unique and effective solutions to local communities ongoing problems in sectors 
                      such as vulnerable child education, poverty reduction, gender and equality, 
                      community awareness on climate, reproductive health and nutrition. 
                </p> 
        </div>
        <div class="col-sm-4">
          
            <h3 class="text-justify">
               Contact Us
        </h3>
        <p class="text-justify">
            <i class="fa fa-map" style="color:gainsboro; font-weight:bold;"></i><br>
                
               Afao/Kajola, Ado Road Ikere-Ekiti.
        </p>
    
         <p class="text-justify" style="padding-right:100px;">
            <i class="fa fa-envelope-o" style="color:gainsboro;font-weight:bold;"></i><br>
            stpaulsafao@gmail.com
         </p>
         <p class="text-justify">
    
            <i class="fa fa-tablet" style="color:gainsboro;font-weight:bold;"></i><br>
            +234-771983900 
        </p>
                <h3 class="text-justify">Quick links</h3>
                <ul style="list-style:none; padding:5px 0 0px 0;" class="text-justify">
                    <li style="padding-bottom:15px;"><a style="text-decoration:none;" href="./">Home</a></li>
                    <li style="padding-bottom:15px;"><a style="text-decoration:none;" href="./Posts">Blog</a></li>
                    <li style="padding-bottom:15px;"><a style="text-decoration:none;" href="">Ministries</a></li>

                </ul>
                
            <h3 class="text-justify">Our PUBLICATIONS</h3>
            <ul style="list-style:none; padding:0px 0 0 0;" class="text-justify">
                <li style="padding-bottom:5px;"><a style="text-decoration:none;" href="ola.docx">one</a></li>
                <li style="padding-bottom:5px;"><a style="text-decoration:none;" href="ola.docx">two</a></li>
                <li style="padding-bottom:5px;"><a style="text-decoration:none;" href="ola.docx">three</a></li>
            </ul>
        </div>
        <div class="col-sm-3" style="padding-top:0; margin-top:0;">
        
                <h3 class="text-justify">Social</h3>
                <ul style="list-style:none; padding:5px 0 0 0;" class="text-justify">
                    <li> <i class="fa fa-twitter" style="font-weight:300;padding-right:5px;padding-bottom:15px;"></i><a style="text-decoration:none;" href="https://twitter.com/aluko_798">Twitter</a></li>
                    <li><i class="fa fa-instagram" style="font-weight:300;padding-right:5px;"></i><a style="text-decoration:none;" href="https://www.instagram.com/olacodex">Instagram</a></li>
                    <li><i class="fa fa-whatsapp" style="font-weight:300;padding-right:5px;"></i><a style="text-decoration:none;" href="https://api.whatsapp.com/send?phone=2348123035681">WhatsApp</a></li>
                </ul>
        </div>
        </div>
        <p class="text-center">&copy 2019 Olawale design | All rights reserved</p>
        <a  style="float:left; text-decoration:none;background:#272E4F; color:aliceblue;" class="btn btn-default" href="#myPage" onclick="topFunction()" id="myBtn">
            <span class="fa fa-arrow-up" style="font-size:30px; "></span> 
        </a>
    </div>
</footer>