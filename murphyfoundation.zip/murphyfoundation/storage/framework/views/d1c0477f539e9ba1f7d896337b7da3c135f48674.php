<?php $__env->startComponent('mail::message'); ?>
# Hello Murphy Foundation,
# You have received the following request.

 <p>My name is <strong><?php echo e($data['name']); ?></strong> from <strong><?php echo e($data['country']); ?>.</strong></p>
 <p>I am moved and impressed by your good works.
     I will like to volunteer to help out.
     <br>
     Below are my contact details and other informations as required on your website, do stay in touch.
 </p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Phone Number:</strong> <?php echo e($data['number']); ?></p>
<p><strong>Gender:</strong> <?php echo e($data['gender']); ?></p>

<br><br>
<p>Warm Regards,</p>
<p>MurphyFoundation.</p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/emails/contact/volunteer-form.blade.php ENDPATH**/ ?>