<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'MurphyFoundation') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <link rel="stylesheet" href="css/animate.min.css">
    <!-- Fonts --> <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Fira+Code&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Grenze&display=swap" rel="stylesheet">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        
    <style>
            body{ font-family: 'Grenze', serif;
         }
         p,li{
           font-size: 20px;
         }
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:15px;
        }
        .container.top span.float{
          float:right;
        }
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: #454242;
    padding-bottom: 20px;
    margin-top:0;
}
.jumbotron h1{
    color: antiquewhite;
    font-weight: bolder;
}        
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
  font: 10;
    color: aliceblue;
    font-size: 12px;
    
}
.fa-instagram,
.fa.fa-whatsapp{
    font: 10;
    color: aliceblue;
    font-size: 12px;
}
.fa-facebook{
    font: 10;
    font-size: 12px;
    color: aliceblue;
}

      .fa:hover{
        
          font: 200;
          font-size: 15px;
      }
      
      div.form-group input.form-control:focus{
          outline:0;
          box-shadow: none;
        }
@media only screen and (max-width: 768px) {
  /* For mobile phones: */
  
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 0px;
    margin-top:0;
    padding-top: 50px;
}
  h2.top{
      font-size: 29px;
    }  
    p.top{
      font-size: 15px;
    }
  
    .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:10px;
        }
        .container.top span.float{
          float:right;
          font-size: 18px;
        }          
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 10;
    color: aliceblue;
    font-size: 12px;
    
}
.fa-instagram{
    font: 10;
    color: aliceblue;
    font-size: 12px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 10;
    font-size: 12px;
    color: aliceblue;
}

      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 15px;
      }
}
         </style>
</head>
<body>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v4.0"></script>
        
            @yield('content')

            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
       
            <script>
                    // When the user scrolls down 20px from the top of the document, show the button
                    window.onscroll = function() {scrollFunction()};
                    
                    function scrollFunction() {
                      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                        document.getElementById("myBtn").style.display = "block";
                      } else {
                        document.getElementById("myBtn").style.display = "none";
                      }
                    }
                    
                    // When the user clicks on the button, scroll to the top of the document
                    function topFunction() {
                      document.body.scrollTop = 0;
                      document.documentElement.scrollTop = 0;
                    }
                    </script>
                     
</body>
</html>
