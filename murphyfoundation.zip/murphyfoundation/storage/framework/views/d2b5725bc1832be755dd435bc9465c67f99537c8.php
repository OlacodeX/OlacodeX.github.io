<?php $__env->startComponent('mail::message'); ?>
# You received the following message From:

<strong>Name</strong> <?php echo e($data['name']); ?>

<strong>Email</strong> <?php echo e($data['email']); ?>


<strong>Message</strong>
<?php echo e($data['message']); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/emails/contact/contact-form.blade.php ENDPATH**/ ?>