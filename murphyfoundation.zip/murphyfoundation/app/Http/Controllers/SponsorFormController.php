<?php

namespace App\Http\Controllers;

use App\Mail\SponsorMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class SponsorFormController extends Controller
{
    //
    public function create(){
        return view('pages.sponsor');
    }
    public function store(){
        
        $data = request()->validate([
            'name' => 'required',
            'number' => 'required',
            'email' => 'required|email',
            'country' => 'required',
            'gender' => 'required',
            'count' => 'required',
            'sex' => 'required',
        ]);

        //Send mail
           
            Mail::to('aluko798@gmail.com')->send(new SponsorMail($data));
          
            return view('pages.sponsor')->with('message', 'Thanks for your message. We\'ll be in touch');
    }
}

