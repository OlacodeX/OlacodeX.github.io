@component('mail::message')
# Hello Murphy Foundation,
# You have received the following request.

 <p>My name is <strong>{{ $data['name']}}</strong> from <strong>{{ $data['country'] }}.</strong></p>
 <p>I am moved and impressed by your good works.
     I will like to join you in giving these young ones a better future by sponsoring 
 <strong>{{$data['count']}} of them</strong>.
     <br>
     Below are my contact details and other informations as required on your website, do stay in touch.
 </p>
<p><strong>Email:</strong> {{ $data['email']}}</p>
<p><strong>Phone Number:</strong> {{ $data['number']}}</p>
<p><strong>Gender:</strong> {{ $data['gender']}}</p>
<p><strong>Preferred gender:</strong> {{ $data['sex']}}</p>

<br><br>
<p>Warm Regards,</p>
<p>MurphyFoundation.</p>
@endcomponent
