<style>
  footer{
    padding: 0;
  }
.col-sm-5 small{
  float:right;
  width:290px;
}
.container.footer{
            background-color:rgb(26, 26, 26);
            color: aliceblue;
            padding-top:0px;
            margin-bottom: 0;
            padding-bottom: 10px;
            font-family: 'Grenze', serif;
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
        }
        footer h3{
            font-size: 22px;
            padding-bottom:0px; 
            padding-top: 30px;
            line-height: 2em;
            text-transform:uppercase;
            color: aliceblue;
        }
        footer p{
            color:  rgb(141, 139, 139);
            line-height: 1.7em;
            font-size: 18px;
        }
        footer .col-sm-5{
            padding-left: 30px;
        }
        footer .col-sm-4{
            padding-left:30px;
        }
         /***Google map**/
         div.mapouter div.gmap_canvas iframe{
           width:400px; 
           height: 400px;
           }
            .mapouter{
              text-align:right;
              height:500px;
              width:600px;
              }
              .gmap_canvas {
                overflow:hidden;
                background:none!important;
                height:400px;
                width:400px; 
                margin-left: 0;
                padding-left: 0;
         }
         footer .col-sm-5 p{
           margin-top:15px; 
           padding:3px;
         }
         .col-sm-5 img{
          width:400px;
           height:200;
         }
@media  only screen and (max-width: 768px) {
  
.col-sm-5 img{
  height: 150px;
  margin-left: 0px;
  width:300px;
}
 
footer .col-sm-5{
            padding-left: 20px;
        }
        footer .col-sm-4{
            padding-left: 20px;
        } 

        footer .col-sm-5 p{
           margin-top:15px; 
           padding:3px 10px 3px 20px;
           font-size: 15px;
         }
         footer .col-sm-5 h3{
          padding-left: 10px;
         }

         /***Google map**/
         div.mapouter div.gmap_canvas iframe{
           width:300px; 
           height: 400px;
           margin-left: 5px;
           margin-right: 1200px;
           }
            .mapouter{
              text-align:right;
              height:500px;
              width:300px;
              }
              .gmap_canvas {
                overflow:hidden;
                background:none!important;
                height:300px;
                width:300px; 
                margin-left: 0;
                padding-left: 0;
                
         }
         div.fb-page{
           margin-left: 5px;
         }
}
</style>
    <div class="container footer">
 <footer>
            <div class="row">
    
    <div class="col-sm-5">
            <h3 class="text-justify">ABOUT US</h3>
            <img src="<?php echo URL::asset('img/logo.jpg'); ?>" class="img-responsive" alt="">
           
            <p class="text-justify">
              Inspired by a life-changing event, Murphy Charitable Foundation was established in 2018 in South Africa (Africa, SA). Over the years, we have become one of the most trusted and effective charitable foundations as we are guided by our Father God, Over the years we have seen too much pain and heartache.
              Our core work stems from the ideology of providing sustainable, 
                  unique and effective solutions to local communities ongoing problems in sectors 
                  such as vulnerable child education, poverty reduction, gender and equality, 
                  community awareness on climate, reproductive health and nutrition. 
            </p> 
            <div class="mapouter"><div class="gmap_canvas"><iframe width="476" height="397" id="gmap_canvas" src="https://maps.google.com/maps?q=Bukedea%20district%2Cuganda&t=&z=9&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://www.enable-javascript.net"></a></div></div>
          </div>
    <div class="col-sm-4">
      
        <h3 class="text-justify">
           Contact Us
    </h3>
    <p class="text-justify">
        <i class="fa fa-map" style="color:green;"></i><br>
            
            Middelburg,South africa<br>
            Uganda Mbale
    </p>

     <p class="text-justify" style="padding-right:100px;">
        <i class="fa fa-envelope-o" style="color:green;"></i><br>
        murphycharity.info@gmail.com <br> murphycharityfoundation.ug@gmail.com
     </p>
     <p class="text-justify">

        <i class="fa fa-tablet" style="color:green;"></i><br>
        +256-771983900 
    </p>
            <h3 class="text-justify">Quick links</h3>
            <ul style="list-style:none; padding:5px 0 0px 0;" class="text-justify">
                <li style="padding-bottom:15px;"><a style="text-decoration:none;color:  rgb(141, 139, 139);" href="donate">Donate to Us</a></li>
            </ul>
    </div>
    <div class="col-sm-3" style="padding-top:0; margin-top:0;">
    
            <h3 class="text-justify">Social</h3>
            <ul style="list-style:none; padding:5px 0 0 0;" class="text-justify">
                <li> <i class="fa fa-twitter" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;padding-bottom:15px;"></i><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="https://twitter.com/ugandamurphy">Twitter</a></li>
                <li><i class="fa fa-instagram" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;"></i><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="">Instagram</a></li>
                <li><i class="fa fa-whatsapp" style="color:  rgb(141, 139, 139); font-weight:300;padding-right:5px;"></i><a style="color:  rgb(141, 139, 139);text-decoration:none;" href="https://api.whatsapp.com/send?phone=256771983900">WhatsApp</a></li>
            </ul> 
            <div class="fb-page" data-href="https://www.facebook.com/murphycharityuganda/" data-tabs="timeline" data-width="" data-height="" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/murphycharityuganda/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/murphycharityuganda/">Murphy charitable foundation uganda</a></blockquote></div>
    </div>
    </div>
    <p class="text-center">&copy 2019 Olawale design | All rights reserved</p>
    <a  style="float:left; text-decoration:none;background:green; color:aliceblue;" class="btn btn-default" href="#myPage" onclick="topFunction()" id="myBtn">
        <span class="fa fa-arrow-up" style="font-size:30px; "></span> 
    </a>
    </footer>
  </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script>
           $(window).scroll(function(){
              $('nav').toggleClass('scrolled', $(this).scrollTop() > 50);
          });
           </script>
   <script>
                   // When the user scrolls down 20px from the top of the document, show the button
                   window.onscroll = function() {scrollFunction()};
                   
                   function scrollFunction() {
                     if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                       document.getElementById("myBtn").style.display = "block";
                     } else {
                       document.getElementById("myBtn").style.display = "none";
                     }
                   }
                   
                   // When the user clicks on the button, scroll to the top of the document
                   function topFunction() {
                     document.body.scrollTop = 0;
                     document.documentElement.scrollTop = 0;
                   }
                   </script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
   
   <?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/inc/footer.blade.php ENDPATH**/ ?>