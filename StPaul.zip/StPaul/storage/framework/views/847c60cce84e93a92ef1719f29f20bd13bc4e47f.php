<style>
div.carousel.slide.one{
    position: absolute;
    top: 0;
}
div.carousel.slide.one div.carousel-inner div.carousel-item img{
    width:1349px;
    height: 700px;
    padding-left: 0px;
}

div.carousel.slide div.carousel-inner div.carousel-item img{
    width:1000px;
    padding-left: 100px;
    height: 350px;
}
div.carousel.slide.one div.carousel-inner div.carousel-item::after{
    content: "";
    display: block;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(rgba(0, 0, 0, 0.849),rgba(0, 0, 0, 0.842));
}
/****
div.carousel.slide.one div.carousel-inner div.carousel-item div.carousel-caption{
  margin: 0;
  background: black;
  width: 10000px;
  padding: 0;
}****/
div.carousel.slide.one div.carousel-inner div.carousel-item div.carousel-caption h1{

   font-family: 'Fira Code', monospace;
   font-size: 35px;
}
div.carousel.slide.one div.carousel-inner div.carousel-item div.carousel-caption h3{
    padding-top: 0px;
   font-family: 'Grenze', serif;
   font-size: 25px;
   font-weight: lighter;
   letter-spacing: 5px;
   color: green;
}
div.carousel.slide.one div.carousel-inner div.carousel-item div.carousel-caption p{
    padding-bottom: 50px;
    font-family: 'Fira Code', monospace;
   text-align: justify;
}
div.carousel-caption h2{
   letter-spacing: 5px;
   line-height: 2em;
   font-weight: bold;
   font-size: 30px;
}
div.carousel.slide.one ul.carousel-indicators{
    padding-bottom: 60px;
}
.row.bl{
padding-top:500px;
margin-top: 150px;
padding-bottom: 100px;
background: #272E4F;
color: gainsboro;
}
.row.bl h4,
.row.bl h5{
    font-weight: bold;
    color: aliceblue;
}
.row.bl h5{
    font-size: 17px;
}
.col-sm-4.first{
    padding-left: 30px;
    border-right: 1px gray solid;
}
.col-sm-4 h5.pad{
    padding-right: 10px;
}
div.row{
    padding-top: 100px;
}     
/**Youtube video***/

.vplayer {
    margin-bottom: 30px;
    position: relative;
    padding-top: 56.25%;
    overflow: hidden;
    cursor: pointer;
    background-color: #000;
}
.vplayer img {
    top: 0;
    left: 0;
    width: 100%;
    opacity: 0.7;
}
.vplayer .plybtn {
    box-shadow: 0 0 30px rgba( 0, 0, 0, 0.6);
    width: 90px;
    height: 60px;
    background-color: red;
    z-index: 1;
    opacity: 0.8;
    margin-left: 280px;
    border-radius: 100px;
}

.vplayer .plybtn:hover {
    padding: 50px 80px;
}
.vplayer .plybtn:before {
    content: "";
    border-style: solid;
    border-width: 15px 0 15px 26.0px;
    border-color: transparent transparent transparent #fff;
}
.vplayer img,
.vplayer .plybtn {
    cursor: pointer;
}
.vplayer img,
.vplayer iframe,
.vplayer .plybtn,
.vplayer .plybtn:before {
    position: absolute;
}
.vplayer .plybtn,
.vplayer .plybtn:before {
    top: 50%;
    left: 50%;
    transform: translate3d( -50%, -50%, 0);
}
.vplayer iframe {
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
}

.row.video{
    background:#ebeff180;
    padding-top: 50px;
    padding-bottom: 100px;
    margin-bottom: 0;
}
.row.video h5{
    font-weight: bold;
}
.row.video a.btn{
    margin-bottom: 30px;
    margin-left: 500px;
    font-weight: bold;
    font-size: 20px;
    padding: 20px 20px;
    background: transparent;
    border: #272E4F 1px solid;
    color: #272E4F;
}
.row.video a.btn:hover{
    background: #272E4F;
    color: antiquewhite;
    padding: 20px 30px;
}
.fa.fa-long-arrow-left,
.fa.fa-long-arrow-right,
.fa.fa-medium{
    color: #272E4F;
    font-weight: bold;
}
.title{
color: #272E4F;
font-weight: bold;
}
div.row.top-0{
padding-top: 0;
}

             
     /*Gallery*/
     .row.gallery{
        padding-top: 0;
        margin-top: 0;
        margin-bottom: 0;
    }
    .container-fluid.gallery .mySlides img{
        height: 700px;
    }
  .container-fluid.gallery img.demo{
        height: 100px;
    }
    .row.bottom{
        padding-left:15px;
        padding-right:15px;
        padding-top: 0;
    }            
* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color: goldenrod;
  font-weight: bold;
  font-size: 40px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 20px;
  padding-right: 20px;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Position the image container (needed to position the left and right arrows) */
.container-fluid.gallery {
  position: relative;
  margin-top: 0px;
  margin-bottom: 0px;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #272E4F;
  padding: 12px 16px;
  color: gainsboro;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}                         
.row.ministry{
background:linear-gradient(rgba(0, 0, 0, 0.555),rgba(8, 8, 8, 0.863)), url('img/bible2.jpg') no-repeat;
color:antiquewhite;
background-size: cover;
background-position: center;
height: 850px;
padding-left: 100px;
padding-right: 100px;
background-attachment: fixed;
margin-top: 0;
}                                 
button.rounded-circle{
background: #abf7cb36;
border-radius: 1000px;
margin-bottom: 20px;
margin-top: 20px;
} 
                                
button.rounded-circle i.fa.fa-cubes{
font-size: 40px;
padding: 30px;
color:antiquewhite;
}
.row.ministry a.btn{
margin-bottom: 30px;
margin-left: 400px;
font-weight: bold;
font-size: 20px;
padding: 20px 20px;
background: transparent;
border: #272E4F 1px solid;
color: antiquewhite;
}
.row.ministry a.btn:hover{
background: #272E4F;
padding: 20px 30px;
}
.row.ministry p{
margin-top: 10px;
text-align: justify;
}
.row.ministry div.text-center{
margin-top: 20px;
}
.row.ministry div.text-center.pad{
padding-left: 30px;
}
i.fa.fa-th{
    font-size: 28px;
    color: #272E4F;
    font-weight: bold;
}
.col-sm-4 div.panel-default div.panel-title img{
    width: 350px;
    height: 300px;
}
.col-sm-4 div.panel-default{
    width: 350px;
    box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
    
}
.col-sm-4 div.panel-default div.panel-body{
    width: 350px;
    height: 200PX;
    padding-left: 20px;
    padding-right: 20px;
    padding-top: 30px;
}
.row.faith{
    padding-left: 40px;
    padding-right: 40px;
}
.row.faith a{
    text-decoration: none;
    color: #222;
}
.row.faith a.btn{
margin-top: 50px;
margin-bottom: 30px;
margin-left: 500px;
font-weight: bold;
font-size: 20px;
padding: 15px 20px;
background: transparent;
border: #272E4F 1px solid;
color: #272E4F;
}
.row.faith a.btn:hover{
background: #272E4F;
color: antiquewhite;
padding: 20px 30px;
}
.row.council{
    padding-left: 50px;
    padding-right: 50px;
    padding-top: 0;
}
.img-container {
position: relative;
width: 25%;
max-width: 100px;
}

.image {
display: block;
width: 280px;
height:280px;
box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
}

.overlay {
position: absolute; 
bottom: 0; 
background: rgb(0, 0, 0);
background: rgba(0, 0, 0, 0.5); /* Black see-through */
color: #f1f1f1; 
width: 280px;
transition: .5s ease;
opacity:0;
color: white;
font-size: 20px;
padding: 20px 10px;
text-align: center;
}

.img-container:hover .overlay {
opacity: 1;
background: #000;
padding-bottom: 50px;
}
.row.council button.btn.btn-info{
border-radius: 100%;
color:  rgb(141, 139, 139); 
padding: 7px;
background:rgba(141, 139, 139, 0.178);
margin-right: 10px;
border: none;
}
.row.council .col-sm-3{
margin-bottom: 20px;
}
.row.council .col-sm-12{
margin-bottom: 30px;
}

.row.prayer{
                    
    background:linear-gradient(rgba(0, 0, 0, 0.555),rgba(8, 8, 8, 0.863)), url('img/priest.jpg') no-repeat;
    color:antiquewhite;
    background-size: cover;
    background-position: center;
    height: 650px;
    padding-left: 100px;
    padding-right: 100px;
    background-attachment: fixed;
    margin-top: 0;
    margin-bottom: 0;
}
.row.prayer button.btn.btn-info{
    margin-bottom: 30px;
    margin-top: 30px;
    margin-left: 70px;
    font-weight: bold;
    font-size: 20px;
    padding: 20px 20px;
    background: transparent;
    border: #272E4F 1px solid;
    color: antiquewhite;
}
.row.prayer button.btn.btn-info:hover{
    background: #272E4F;
    color: antiquewhite;
    padding: 20px 30px;
}
button.close{
    margin-left: 200px;
    color: red;
}
i.fa.fa-language{
    font-size: 28px;
    color: antiquewhite;
    font-weight: bold;
}
.modal{
    color: antiquewhite;
}
.modal-content,
.modal-body,
.modal-header{
    background:#272E4F;
}
</style>
<?php /**PATH C:\xampp\htdocs\StPaul\resources\views/inc/home.blade.php ENDPATH**/ ?>