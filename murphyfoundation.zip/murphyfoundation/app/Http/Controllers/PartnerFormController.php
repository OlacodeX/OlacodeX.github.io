<?php

namespace App\Http\Controllers;

use App\Mail\PartnerMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class PartnerFormController extends Controller
{
    //
    public function create(){
        return view('pages.partner');
    }
    public function store(){
        
        $data = request()->validate([
            'name' => 'required',
            'number' => 'required',
            'email' => 'required|email',
            'country' => 'required',
        ]);

        //Send mail
           
            Mail::to('aluko798@gmail.com')->send(new PartnerMail($data));
          
            return view('pages.partner')->with('message', 'Thanks for your message. We\'ll be in touch');
    }
}

