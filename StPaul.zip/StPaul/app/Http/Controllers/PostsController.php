<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
// Bring in the model
// This allows me to interact with my db
use App\Posts; 
//Alternatively, i can use normal mysql query by adding
use DB;

class PostsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
   public function __construct()
   {
       $this->middleware('auth', ['except' => ['index', 'show']]);
   }

    public function index()
    {
        
       $posts = Posts::orderBy('created_at', 'desc')->paginate(4);
       return view("posts.index")->with('posts', $posts); 
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('posts.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
       $this->validate($request, [
           'title' => 'required',
           'body' => 'required',
            //image means it must be in image format|nullable means the field is optional, then max size is 1999
            'cover_image' => 'image|nullable|max:1999'
            ]);
            //Handle file upload
            if($request->hasFile('cover_image')){
                //Get file name with the extension
                $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
                //get just file name
                $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
    
                // Get just Ext
                $extension = $request->file('cover_image')->getClientOriginalExtension();
    
                // File name to store
                $fileNameTostore = $filename.'_'.time().'.'.$extension;
    
                // Upload Image
              $path = $request->file('cover_image')->storeAs('public/img', $fileNameTostore);
    
            }
            else{
                //default image for post if none was choosed
                $fileNameTostore = 'default.png';
            }
        // Create new post
       $post = new Posts;
       $post->title = $request->input('title');//This will get the user input for title
        //add the user id to post
       $post->user_id = auth()->user()->id;
       $post->cover_image = $fileNameTostore;
       $post->body = $request->input('body');
        //Save to db
        $post->save();
        //print success message and redirect
        return redirect('home')->with('success', 'Post Created');//I just set the message for session(success).

    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        
        $post = Posts::find($id);
       // return view('posts.showpublic')->with('post', $post);
        return view('posts.show')->with('post', $post);//
    
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    { 
        $post = Posts::find($id);
        return view('posts.edit')->with('post', $post);
   
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'title' => 'required',
            'body' => 'required',
        ]);

        //Handle file upload
        if($request->hasFile('cover_image')){
            //Get file name with the extension
            $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
            //get just file name
           $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);

            // Get just Ext
           $extension = $request->file('cover_image')->getClientOriginalExtension();

            // File name to store
           $fileNameTostore = $filename.'_'.time().'.'.$extension;

            // Upload Image
            $path = $request->file('cover_image')->storeAs('public/img', $fileNameTostore);

        }
    
        $post = Posts::find($id);
        $post->title = $request->input('title');//This will get the user input for title
       $post->body = $request->input('body');
        if($request->hasFile('cover_image')){
           $post->cover_image = $fileNameTostore;
       } 
        //Save to db
        $post->save();
        //print success message and redirect
        return redirect('home')->with('success', 'Post Updated');//I just set the message for session(success).

    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        
       $post = Posts::find($id);

       //If post is deleted, delete image too
              if($post->cover_image != 'default.png'){
                   //Delete image
                 Storage::delete('public/img'.$post->cover_image);
               }
       
               $post->delete();
       
               return redirect('home')->with('success', 'Post Deleted');
    }
}
