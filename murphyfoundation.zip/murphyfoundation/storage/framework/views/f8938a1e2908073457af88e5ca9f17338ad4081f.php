<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\murphyfoundation\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>