@component('mail::message')
# Hello Murphy Foundation,

<p>{{ $data['name']}} has the following message for you.</p>

<p>{{ $data['message'] }}</p>
<p>The contact details are below:
    <li style="list-style:none;"><strong>Email:</strong> {{ $data['email']}}</li>
    <li style="list-style:none;"><strong>Phone Number:</strong> {{ $data['number']}}</li>
</p>

<br><br>
<p>Warm Regards,</p>
<p>MurphyFoundation.</p>
@endcomponent
