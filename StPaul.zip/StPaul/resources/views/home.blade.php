@extends('layouts.app')

@section('content')
<div class="container dashbd">
    <div class="justify-content-center">
        <div class="col-md-12">
            <div class="panel-default">
                <div class="panel-heading">
                    <h5>Welcome  {{ Auth::user()->name }}</h5>
                    <h3 style="font-family: 'Wallpoet', cursive;">Your Catalogue</h3></div>
                <hr>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <a href="Posts/create" class="btn btn-primary btn-sm">New Article</a><br><br>
                    <h2 class="text-justify" style="font-family: 'Wallpoet', cursive;">Your Articles</h2>
                    @if (count($posts) >= 0)
                    <table class="table table-stripped">
                        <tr>
                            <th>Title</th>
                            <th></th>
                            <th>Action</th>
                        </tr>
                        @foreach ($posts as $post)
                        <tr>
                        <td>{{$post->title}}</td>
                        <td><a href="Posts/{{$post->id}}/edit" class="btn btn-info btn-sm">Edit</a></td>
                        <td>
                                {!!Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-left', 'style' => 'margin-right:20px;'])!!}

                                {{Form::hidden('_method', 'DELETE')}}
                                {{Form::submit('Delete Article', ['class' => 'btn btn-danger btn-sm'])}}
                                {!!Form::close()!!}
                        </td>
                        </tr>
                        @endforeach
                    </table>
                    @else
                    <p>You have no posts yet</p>    
                    @endif
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
