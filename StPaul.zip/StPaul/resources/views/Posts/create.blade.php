@extends('layouts.app')
<style>
label{
    font-family: 'Supermercado One', cursive;
}
div.container.create{
    margin-top:50px; 
    padding-bottom:100px;
    width:70%;
}
h1.create{
    margin-bottom: 50px;
}
</style>
@section('content')
<div class="container create">
    <h1 class="create">Upload Article</h1>
    <!---If file upload is involved always add enctype to your opening
        form tag and set it to multipart/form-data--->
   {!! Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) /** The action should be the block of code in the store function in PostsController
   **/ !!}
    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        {{Form::label('title', 'Title')}}
        <!--This is the input field with type=text, name=title, value='' since it is a text field, then bootstrap class and then placeholder--->
        {{Form::text('title', '', [ 'class' => 'form-control', 'placeholder' => 'Article title'])}}
    </div>
    
    <div class="form-group">
            {{Form::label('cover image', 'Cover Image')}}
           {{Form::file('cover_image', ['class' => 'form-control'])}}
    </div>
    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        {{Form::label('body', 'Body')}}
        <!--This is the input field with type=textarea, name=body, value='' since it is a text field, then bootstrap class and then placeholder--->
        {{Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Article body'])}}
    </div>
    {{Form::submit('Upload Article', ['class' => 'btn btn-success btn-md pull-left', 'style' => 'text-transform:uppercase;'])}}
   {!! Form::close() !!}
   <a href="../dashboard" class="btn btn-primary btn-md pull-right">Dashboard</a>

</div>
@endsection