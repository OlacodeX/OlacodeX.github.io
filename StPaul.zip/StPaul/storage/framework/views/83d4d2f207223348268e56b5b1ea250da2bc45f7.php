<?php $__env->startSection('content'); ?>
<div class="container dashbd">
    <div class="justify-content-center">
        <div class="col-md-12">
            <div class="panel-default">
                <div class="panel-heading">
                    <h5>Welcome  <?php echo e(Auth::user()->name); ?></h5>
                    <h3 style="font-family: 'Wallpoet', cursive;">Your Catalogue</h3></div>
                <hr>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <a href="Posts/create" class="btn btn-primary btn-sm">New Article</a><br><br>
                    <h2 class="text-justify" style="font-family: 'Wallpoet', cursive;">Your Articles</h2>
                    <?php if(count($posts) >= 0): ?>
                    <table class="table table-stripped">
                        <tr>
                            <th>Title</th>
                            <th></th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <td><?php echo e($post->title); ?></td>
                        <td><a href="Posts/<?php echo e($post->id); ?>/edit" class="btn btn-info btn-sm">Edit</a></td>
                        <td>
                                <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-left', 'style' => 'margin-right:20px;']); ?>


                                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                <?php echo e(Form::submit('Delete Article', ['class' => 'btn btn-danger btn-sm'])); ?>

                                <?php echo Form::close(); ?>

                        </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php else: ?>
                    <p>You have no posts yet</p>    
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StPaul\resources\views/home.blade.php ENDPATH**/ ?>