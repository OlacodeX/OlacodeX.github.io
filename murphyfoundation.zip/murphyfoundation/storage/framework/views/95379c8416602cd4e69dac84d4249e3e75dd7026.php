

<style>
  .navbar-nav{
       padding-left: 0px;
    }
    ul.navbar-nav li a.active{
      color:black;
      padding: 40px 0 0 400px;
      font-size: 18px;
       font-weight: bold;
    }
    ul.navbar-nav li a{
      text-decoration: none;
      font-family: 'Grenze', serif;
      color:#454242;
    }
    ul.navbar-nav li a.about
    {
      padding: 40px 30px 0 40px;
    font-size: 18px; 
    color:#454242;
    }
    ul.navbar-nav li a.home{
      padding-left: 300px;
    font-size: 18px; 
    color:#454242;
    }
    ul.navbar-nav li a.contact,
    ul.navbar-nav li a.donate{
      padding: 40px 30px 0 5px;
    font-size: 18px; 
    color:#454242;
    }
      /**drops down item on hover***/ 
  .dropdown:hover .dropdown-menu{
    display: block;
  }
    @media  only screen and (max-width: 768px) {
      /* For mobile phones: */
      .navbar-toggler{
          text-align: center;
       border: none;   
      }
      .navbar-toggler-icon.fa.fa-list{
        color: green;
        margin-left: 20px;
      }
    ul.navbar-nav li a.active,
    ul.navbar-nav li a.about,
    ul.navbar-nav li a.contact,
    ul.navbar-nav li a.home,
    ul.navbar-nav li a.donate{
      padding: 0;
      padding-bottom: 15px;
    }
    }  
    </style>
    <nav class="navbar navbar-expand-md justify-content-center">
              <!-- Toggler/collapsibe Button -->
           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
              <span class="navbar-toggler-icon fa fa-list"></span>
            </button>
              <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                  <li class="text-center"><a class="home" href="./">HOME</a></li> 
                  <li class="text-center"><a href="about" class="about">ABOUT US</a></li>
                  <li class="text-center"><a href="contact" class="contact">CONTACT US</a></li>
                  <li class="text-center"><a href="donate" class="donate">DONATE</a></li> 
                  <li class="text-center dropdown">
                   <a href="#" id="navbardrop" data-toggle="dropdown">
                    Engage With Us <i class="fa fa-angle-down"></i>
                   </a>
                   <div class="dropdown-menu">
                          <a class="dropdown-item" href="newsletter">Newsletter</a>
                          <a class="dropdown-item" href="partner">Become Our Partner</a>
                          <a class="dropdown-item" href="sponsor">Sponsor a Child</a>
                          <a class="dropdown-item" href="volunteer">Volunteer</a>
                   </div>
       </li>

                </ul>
              </div>
          </nav>  <?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/inc/nav.blade.php ENDPATH**/ ?>