<?php $__env->startComponent('mail::message'); ?>
# Hello Murphy Foundation,
# You have received the following request.

 <p>My name is <strong><?php echo e($data['name']); ?></strong> from <strong><?php echo e($data['country']); ?>.</strong></p>
 <p>I am moved and impressed by your good works.
     I will like to join you in giving these young ones a better future by sponsoring 
 <strong><?php echo e($data['count']); ?> of them</strong>.
     <br>
     Below are my contact details and other informations as required on your website, do stay in touch.
 </p>
<p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
<p><strong>Phone Number:</strong> <?php echo e($data['number']); ?></p>
<p><strong>Gender:</strong> <?php echo e($data['gender']); ?></p>
<p><strong>Preferred gender:</strong> <?php echo e($data['sex']); ?></p>

<br><br>
<p>Warm Regards,</p>
<p>MurphyFoundation.</p>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/emails/contact/sponsor-form.blade.php ENDPATH**/ ?>