<div class="container top">
        
    <p style="color:aliceblue;">
        <a style="color:aliceblue;" href="https://www.twitter.com/ugandamurphy"><i class="fa fa-twitter"></i></a>
        <a href="https://api.whatsapp.com/send?phone=256771983900" style="color:aliceblue;"><i class="fa fa-whatsapp" style="font-weight:300;padding-right:5px;"></i></a> 
          
        <a href="https://www.facebook.com/murphycharityuganda/" style="color:aliceblue;"><i class="fa fa-facebook"></i></a>
<span class="float">
  <a target="blank"style="text-decoration:none; color:f0f8ff;" href="https://mail.google.com/mail/?fs=1&view=cm&to=murphycharity.info@gmail.com"><i class="fa fa-envelope-o" style="color:white;"></i>
  murphycharity.info@gmail.com</a>
</span>
</p>
</div><!---end div for container top---->
