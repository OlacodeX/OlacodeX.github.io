@extends('layouts.app')
<style>
        label{
            font-family: 'Supermercado One', cursive;
        }
        

</style>
@section('content')
<div class="container" style="margin-top:150px; padding-bottom:100px;width:70%;">
    <h1>Edit Article</h1>
   {!! Form::open(['action' => ['PostsController@update', $post->id]/**the id tells it the post to update*/, 'method' => 'POST',  'enctype' => 'multipart/form-data']) /** The action should be the block of code in the store function in PostsController
   **/ !!}
    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        {{Form::label('title', 'Title')}}
        <!--This is the input field with type=text, name=title, value=the title from db, then bootstrap class and then placeholder--->
        {{Form::text('title', $post->title, [ 'class' => 'form-control', 'placeholder' => 'Article title'])}}
    </div>
    
    <div class="form-group">
            {{Form::label('cover image', 'Cover Image')}}
           {{Form::file('cover_image', ['class' => 'form-control'])}}
    </div>
    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        {{Form::label('body', 'Body')}}
        <!--This is the input field with type=textarea, name=body, value='' since it is a text field, then bootstrap class and then placeholder--->
        {{Form::textarea('body', $post->body, ['class' => 'form-control', 'placeholder' => 'Research Summary/Abstract'])}}
    </div>
    <!---To update in laravel the form method must be PUT but we can have that in normal form tag
        So we create the hidden type below--->
    {{Form::hidden('_method', 'PUT')}}
    {{Form::submit('Update Article', ['class' => 'btn btn-success btn-md pull-left', 'style' => 'text-transform:uppercase;'])}}
   {!! Form::close() !!}
<p class="pull-right edit">
    <a href="../../posts" class="btn btn-success btn-md">Blog</a>
    <a href="../../dashboard" class="btn btn-primary btn-md">Dashboard</a>

</p>
</div>
@endsection