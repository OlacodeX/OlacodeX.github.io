<style>
    .row.bg{
                    margin: 0;
                    padding: 0;
                    background:linear-gradient(rgba(0, 0, 0, 0.9),rgba(8, 8, 8, 0.863)), url('img/b3.jpg') no-repeat;
                    font-family: 'Fira Code', monospace;
                    background-size: cover;
                     background-position: top;
                    background-attachment:fixed;
        
    }
    nav.navbar.navbar-expand-md.fixed-top.bg-light{
        background: transparent;
    }
    hr{
        background: aliceblue;
    }
   .container h3.text-justify{
        color: antiquewhite;
        font-weight: bold;
        margin-top: 50px;
        margin-bottom: 50px;
         line-height:1.8em;
          font-size:3em;
    }
   a{
        text-decoration: none;
        color:antiquewhite;
     } 
    a i.fa{
        color: #272E4F;
        font-size: 15px;
        font-weight: bold;
    }  
    .btn.btn-info{
        background-color: #272E4F;
    }
    .btn.btn-info:hover{
        background-color: transparent;
        color: #272E4F;
    }
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 100;
    color: aliceblue;
    font-size: 15px;
    
}
.fa-instagram{
    font: 100;
    color: aliceblue;
    font-size: 15px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}

.fa-github{
    color: rgb(0, 0, 0);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}
      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 25px;
      }
       
div.jumbotron{
    margin-top: 80px;
    padding-top: 100px;
    padding-bottom: 100px;
    border-radius: 0;
    background-color: #272E4F;
    margin-bottom: 0;
}
.jumbotron h1{
    
    font-weight: bolder;
}
       div.col-md-8{
            
        box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
        padding-bottom:20px;
        margin:0;
        padding-left:0;
        padding-right:0;
        height: 250px;
        margin-bottom: 20px;
        border-radius: 0;
        }
        div.col-md-4{
            margin-right: 0;
            padding-right: 0;
            margin-bottom: 20px;
        }
        div.col-md-4 img{
            margin-right: 0;
            padding-right: 0;
            height:250px;
            width:370px;
            box-shadow: 10px 10px 12px 10px rgba(0, 0, 0, 0.2);
        }
        div.card {
        max-width: 800px;
        margin: 0;
        box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
        height: 250px;
        text-align: justify;
        font-family: 'Grenze', serif;
        padding-left: 10px;
        border-radius: 0;
        }
        .card h3{
            color: rgb(20, 20, 20);
            font-size: 25px;
            padding-left: 14px;
        }
        .card h4{
            color: rgb(141, 137, 137);
            font-size: 14px;
            font-weight: lighter;
        }
        .title {
            color: grey;
            font-size: 18px;
            }
            p{
                margin-top: 40px;
                font-size: 15px;
            }
            h4.body{
                padding-bottom:10px; 
                padding-right:30px; 
                padding-left:15px;
                font-family: 'Fira Code', monospace;
            } 
            footer{
                color:gainsboro;
            }
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
  h3.title{
      font-size: 20px;
      font-weight: normal;
  }
  h4.body{
                padding-bottom:150px; 
                padding-right:30px; 
                padding-left:15px;
                font-family: 'Fira Code', monospace;
            } 
            
            p{
                margin-top: 40px;
                font-size: 10px;
            }
        .card {
        max-width: 800px;
        margin: 0;
        
        height: 300px;
        text-align: justify;
        font-family: 'Grenze', serif;
        }
        
        div.col-md-9{
            
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
            padding-bottom:100px;
            margin:0;
            padding-left:0;
            padding-right:0;
            height: 300px;
            }
        footer{
            padding-top:50px;
             padding-right:0px; 
             padding-left:0px;
             margin: 0 11px;
             } 
        footer .col-sm-12{
            padding: 0;
            margin: 0;
        }
}
</style>
<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    
    <h1 class="text-center" style="color: antiquewhite;">
<?php echo e(config('app.name', 'Laravel')); ?> Blog</h1>
    <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>
</div>
<div class="row bg">
    <?php if(
        //if there is data in the db
    count($posts) > 0
    ): ?>
<?php $__currentLoopData = // Loop through them
            $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <div class="container">
     <div class="col-sm-12">
    <h3 class="text-justify">Recent Posts</h3>
    
</div>
<div class="row">
        <?php $__currentLoopData = // Loop through them
                    $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="col-md-4">
                <!-----
                    $post->title i.e the title field from db
                    created_at date created from db
                    ------>
                <a href="Posts/<?php echo e($post->id); ?>" style="text-decoration: none;">
                            <img src="storage/img/<?php echo e($post->cover_image); ?>" class="img-responsive" alt="">
               
            </a>
            </div>
            <div class="col-md-8">
                <a href="Posts/<?php echo e($post->id); ?>" style="text-decoration: none;color:grey;">
                           
            <!-----
                $post->title i.e the title field from db
                created_at date created from db
                ------>
            <div class="card">
               <p style="font-style:italic;padding-left:10px;"><?php echo Str::words( $post->created_at,1); ?></p>
                      <h3 class="title"><?php echo e($post->title); ?> <!-----This takes me to a page 
                            for the particular post which i will populate with the show function
                        in the PostsController.php.------>
                    </h3>
                    <h4 class="body"> <?php echo Str::words( $post->body,25); ?> <br><br>
                        <a href="" class="btn pull-left btn-lg">
                        <i class="fa fa-envelope"></i><i class="fa fa-paperclip"></i> <i class="fa fa-print"></i>   
                        </a>  <br>
                           <br> <a href="Posts/<?php echo e($post->id); ?>" class="btn btn-info btn-md pull-right">Read More</a>
                            

                    </h4>
                   
            </div>
        </a>
       
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="col-md-12" style="text-align:right;">
        <!-----The pagination link----->
        <?php echo e($posts->links()); ?>

</div>
    <?php else: ?>
    <p>No post found</p>
        
    <?php endif; ?>
</div>
</div>
</div>
    <div class="row footer" style="padding:0; margin:0;">
    <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StPaul\resources\views/posts/index.blade.php ENDPATH**/ ?>