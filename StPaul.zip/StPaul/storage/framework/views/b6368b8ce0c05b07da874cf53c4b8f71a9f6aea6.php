<style>
   a{
        text-decoration: none;
        color:antiquewhite;
     } 
    a i.fa{
        color: green;
        font-size: 15px;
        font-weight: bold;
    }  
    .btn.btn-info{
        background-color: green;
    }
    .btn.btn-info:hover{
        background-color: green;
    }
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 100;
    color: aliceblue;
    font-size: 15px;
    
}
.fa-instagram{
    font: 100;
    color: aliceblue;
    font-size: 15px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}

.fa-github{
    color: rgb(0, 0, 0);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}
      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 25px;
      }
       
       
nav.navbar-default{
    padding:0; margin:0;
    background-color: transparent;
    border: none;
}
.jumbotron h1{
    
    font-weight: bolder;
}
footer{
        background-color:rgb(26, 26, 26);
        color: aliceblue;
        padding-top:50px;
    }
    footer h3{
        font-size: 18px;
    }
    h3.title{
        padding-left:10px;
        padding-right: 10px;
        padding-bottom:3px;
    }
    footer p{
        color:  rgb(141, 139, 139);
    }
    .carousel.slide{
       height:400px;
       padding-top: 0;
       margin-top: 0;
    }
    .carousel.slide .item h2{
        padding-bottom:5px;
        margin-bottom:0;
        margin-right:500px;
    }
    div.carousel.slide div.item a{margin-right:500px;}
    div.carousel.slide div.item h4 {padding-bottom:0px;margin-right:500px; padding-top:20px;}
    div.carousel.slide div.item small{margin-right:500px;color: antiquewhite;}
    .slide img,
    .carousel-inner img{
            width:100%; 
            height: 50%;
        }
        div.carousel-inner{
            height: 450px;
        }
        
        div.carousel-caption{
            padding-bottom: 300px;
            width: 100%;
        }
        .carousel-caption h6{
            font-size: 15px;
            line-height: 1.7em;
            padding: 5px;
        }
        .col-sm-9,.col-sm-3{
            padding-top: 90px;
            font-family: 'Grenze', serif;
        }
        .col-sm-3 img{
            width:100px;
            height: 50px;
        }
        div.col-md-9{
            
        box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
        padding-bottom:20px;
        margin:0;
        padding-left:0;
        padding-right:0;
        height: 250px;
        }
        .card {
        max-width: 800px;
        margin: 0;
        
        height: 250px;
        text-align: justify;
        font-family: 'Grenze', serif;
        }
        .card:hover{

            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
        }
        .card h3{
            color: rgb(20, 20, 20);
            font-size: 25px;
        }
        .card h4{
            color: rgb(141, 137, 137);
            font-size: 14px;
            font-weight: lighter;
        }
        .title {
            color: grey;
            font-size: 18px;
            }
            p{
                margin-top: 40px;
                color: rgb(34, 33, 33);
                font-size: 15px;
            }
            .col-sm-3 aside a{
                text-decoration: none;
            color: rgb(20, 20, 20);
            font-size: 20px;
            }   

            h4.body{
                padding-bottom:10px; 
                padding-right:30px; 
                padding-left:15px;
                font-family: 'Fira Code', monospace;
            } 
            
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
  h3.title{
      font-size: 20px;
      font-weight: normal;
  }
  h4.body{
                padding-bottom:150px; 
                padding-right:30px; 
                padding-left:15px;
                font-family: 'Fira Code', monospace;
            } 
            
            p{
                margin-top: 40px;
                color: rgb(34, 33, 33);
                font-size: 10px;
            }
  .carousel.slide{
       height:200px;
       padding-top: 0;
       margin-top: 0;
    }
    
    .carousel.slide .item h2{
        padding-bottom:5px;
        margin-bottom:0;
        margin-right:50px;
        padding-top: 100px;
        font-size: large;
        color:bisque;
    }
    div.carousel.slide div.item a.btn.btn-primary{margin-bottom:30px;}
    div.carousel.slide div.item a{margin-right:50px;}
    div.carousel.slide div.item h4 {padding-bottom:0px;margin-right:50px; padding-top:0px;}
    div.carousel.slide div.item small{margin-right:50px;color: antiquewhite; font-size:xx-small}
    .slide img,
    .carousel-inner img{
            width:100%; 
            height: 1000px;
        }
        div.carousel-inner{
            height: 250px;
        }
        
        div.carousel-caption{
            padding-bottom:0px;
            width: 100%;
        }
        .carousel-caption h6{
            font-size: 10px;
            line-height: 1.2em;
            padding: 5px;
        }
        .card {
        max-width: 800px;
        margin: 0;
        
        height: 300px;
        text-align: justify;
        font-family: 'Grenze', serif;
        }
        
        div.col-md-9{
            
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
            padding-bottom:100px;
            margin:0;
            padding-left:0;
            padding-right:0;
            height: 300px;
            }
        .col-sm-9,.col-sm-3{
            padding-top: 10px;
            font-family: 'Grenze', serif;
        }
        .col-sm-9{
            padding-bottom: 200px;
        }
        .col-sm-5{
            padding-right:0px;
            }
        footer{
            padding-top:50px;
             padding-right:0px; 
             padding-left:0px;
             margin: 0 11px;
             } 
        footer .col-sm-12{
            padding: 0;
            margin: 0;
        }
}
</style>
<?php $__env->startSection('content'); ?>
<div class="jumbotron" style="margin-top:100px; background:#000000">
    
    <h1 class="text-center" style="color: antiquewhite;">
<?php echo e(config('app.name', 'Laravel')); ?> Blog</h1>
    <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>
</div>
    <?php if(
        //if there is data in the db
    count($posts) > 0
    ): ?>
<?php $__currentLoopData = // Loop through them
            $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <div class="container">
     <div class="col-sm-12">
    <h3 class="text-justify" style="color: antiquewhite; line-height:1.8em; font-size:3em;">Recent Posts</h3>
        <?php $__currentLoopData = // Loop through them
                    $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="posts/<?php echo e($post->id); ?>" style="text-decoration: none;color:grey;">
                       
            <div class="col-md-9">
            <!-----
                $post->title i.e the title field from db
                created_at date created from db
                ------>
            <div class="card">
               <p style="font-style:italic;padding-left:10px;"><?php echo Str::words( $post->created_at,1); ?></p>
                      <h3 class="title"><?php echo e($post->title); ?> <!-----This takes me to a page 
                            for the particular post which i will populate with the show function
                        in the PostsController.php.------>
                    </h3>
                    <h4 class="body"> <?php echo Str::words( $post->body,25); ?> <br><br>
                        <a href="" class="btn pull-left btn-lg">
                        <i class="fa fa-envelope"></i><i class="fa fa-paperclip"></i> <i class="fa fa-print"></i>   
                        </a>  <br>
                           <br> <a href="posts/<?php echo e($post->id); ?>" class="btn btn-info btn-md pull-right">Read More</a>
                            

                    </h4>
                   
            </div>
       
        </div>
    </a>
        
        <div class="col-md-3" style="padding-bottom:20px;margin:0;padding-left:0;padding-right:0;">
                <!-----
                    $post->title i.e the title field from db
                    created_at date created from db
                    ------>
                <a href="posts/<?php echo e($post->id); ?>" style="text-decoration: none;">
                            <img src="storage/img/cover_images/<?php echo e($post->cover_image); ?>" class="img-responsive" alt="" style="height:250px;width:350px;">
               
            </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
<div class="col-md-12" style="text-align:right;">
        <!-----The pagination link----->
        <?php echo e($posts->links()); ?>

</div>
    <?php else: ?>
    <p>No post found</p>
        
    <?php endif; ?>

</div>
    </div>
    <div class="container-fluid" style="padding:0; margin:0;">
    <?php echo $__env->make('inc.footerpost', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StPaul\resources\views/Posts/index.blade.php ENDPATH**/ ?>