<style>

body{
            margin: 0;
            padding: 0;
            background:linear-gradient(rgba(0, 0, 0, 0.995),rgba(8, 8, 8, 0.863)),url('img/sus1.webp') no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            overflow-x: hidden;
            height: 100%;
            width: 100%;
            color: #454242;
            font-family: 'Grenze', serif;
        }
        
        .btn.btn-success{
          color:#454242;
            border-radius: 25px;
            background: transparent;
        }
        #myBtn {
                    display: none;
                    position: fixed;
                    bottom: 20px;
                    right: 30px;
                    z-index: 99;
                    font-size: 18px;
                    border: none;
                    outline: none;
                    color: #454242;
                    cursor: pointer;
                    padding: 15px;
                    border-radius: 4px;
                }
                
                #myBtn:hover {
                    background-color: #555;
                }
                /*Gallery*/
    .container.gallery .mySlides img{
        height: 300px;
    }
    .container.gallery img.demo{
        height: 100px;
    }
    .row.bottom{
        padding-left:15px;
        padding-right:15px;
    }            
* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

/* Position the image container (needed to position the left and right arrows) */
.container.gallery {
  position: relative;
  margin-top: 40px;
  margin-bottom: 40px;
}

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #222;
  padding: 2px 16px;
  color: #454242;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}
/************************************************/

.row.act .col-sm-4 .panel-body{
      border: none;
      background:#000;
      padding-bottom: 30px;
      height: 380px;
      color: #454242;
  }
  .row.act .col-sm-4 .panel-default{
      border: none;
      width: 370px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }
.row.act .col-sm-4 .fa{
     font-size: 85px;
     color: green;
     padding-top: 40px;
 }
.row.act .col-sm-4 .panel-default.bd .panel-body{
    background: rgb(240, 243, 245);
     color: green;
     background-size: cover;
     background-position: center;
  }
  .row.act .col-sm-4 .panel-default.habitat .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act .col-sm-4 .panel-default.A-for .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act{
     padding-right: 20px;

  }
  .col-sm-6.first{
      margin-right: 0;
      padding-right: 0;
  }
  .col-sm-6.first .panel-default{
    margin-right:0px; 
    margin-left:110px;
  }
  .col-sm-6.last{
      margin-left: 0;
      padding-left: 0;
  }
  
  .row.help .panel-default .panel-body{
    background: rgb(240, 243, 245);
     color: green;
      height: 350px;
      margin-right: 0;
      width: 450px;
      margin-bottom: 40px;
  }
  .row.help .panel-default .panel-body.img{
            background:url('img/help.webp') no-repeat;
            background-size: cover;
            margin-left: 0;
            background-position: center;
  }
   a{
        text-decoration: none;
     }           
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 100;
    color: aliceblue;
    font-size: 15px;
    
}
.fa-instagram{
    font: 100;
    color: aliceblue;
    font-size: 15px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}

.fa-github{
    color: rgb(0, 0, 0);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}
      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 25px;
      }
       
       
nav.navbar-default{
    padding:0; margin:0;
    background-color: transparent;
    border: none;
}
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: #454242;
    padding-bottom: 20px;
    margin-top:0;
}
.jumbotron h1{
    color: #454242;
    font-weight: bolder;
}
footer{
        background-color:rgb(26, 26, 26);
        margin:0 36px;
        color: aliceblue;
        padding-top:20px;
        padding-right:20px; 
        padding-left:30px;
    }
    footer h3{
        font-size: 18px;
    }
    footer p{
        color:  rgb(141, 139, 139);
    }
div.carousel.slide div.carousel-inner div.carousel-item::after{
    content: "";
    display: block;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    background: linear-gradient(rgba(0, 0, 0, 0.5),rgba(0, 0, 0, 0.7));
}
    .carousel.slide{
       height:400px;
       padding-top: 0;
       margin-top: 0;
    }
    .carousel.slide .item h2{
        padding-bottom:5px;
        margin-bottom:0;
    }
    div.carousel.slide div.item a{margin-right:500px;}
    div.carousel.slide div.item h4 {padding-bottom:0px;margin-right:500px; padding-top:20px;}
    div.carousel.slide div.item small{margin-right:500px;color:#666464;}
    .slide img,
    .carousel-inner img{
            width:1140px; 
            height:400px;
        }
        div.carousel-inner{
            height: 450px;
        }
div.carousel.slide div.carousel-inner div.carousel-item div.carousel-caption h1{
  
   font-family: 'Fira Code', monospace;
   font-size: 35px;
}
div.carousel.slide div.carousel-inner div.carousel-item div.carousel-caption h3{
    padding-top: 100px;
   font-family: 'Grenze', serif;
   font-size: 25px;
   font-weight: bold;
   letter-spacing: 5px;
   color:lawngreen;
}
div.carousel.slide div.carousel-inner div.carousel-item div.carousel-caption p{
    padding-bottom: 50px;
    font-family: 'Fira Code', monospace;
   text-align: justify;
}
div.carousel-caption h2{
   letter-spacing: 5px;
   line-height: 2em;
   font-weight: bold;
   font-size: 30px;
}
div.carousel.slide ul.carousel-indicators{
    padding-bottom: 10px;
}

        .col-sm-9,.col-sm-3{
            padding-top: 90px;
            font-family: 'Grenze', serif;
        }
        .col-sm-3 img{
            width:100px;
            height: 50px;
        }
        .col-sm-5{padding-right:200px;}
        .card {
        max-width: 350px;
        margin: 0;
        text-align: justify;
        font-family: 'Grenze', serif;
        border: 0.2px solid rgba(194, 194, 194, 0.363);
        }
        .card:hover{

            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
        }
        .card h3{
            color: rgb(20, 20, 20);
            font-size: 25px;
        }
        .card h4{
            color: rgb(141, 137, 137);
            font-size: 14px;
            font-weight: lighter;
        }
        .title {
            color: grey;
            font-size: 18px;
            }
            small{
                margin-top: 40px;
                color: rgb(34, 33, 33);
                line-height: 1.5em;
            }
            .col-sm-3 aside a{
                text-decoration: none;
            color: rgb(20, 20, 20);
            font-size: 20px;
            }    
            
        .row.gallery .col-sm-6 img{
            width: 600px;
            height: 400px;
        }
        .row.gallery{
            padding-left: 0;
            margin-left: 0;
        }
       
        .container{
            box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
            color:#666464;
            background:#FEFDFD;
        }
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:15px;
        }
        .container.top span.float{
          float:right;
        }
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
  
  .row.act .col-sm-4 .panel-default{
      border: none;
      width: 300px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }
  .carousel.slide{
       height:350px;
       padding-top: 0;
       margin-top: 0;
    }
    
    .slide img,
    .carousel-inner img{
            width:100%; 
            height: 350px;
        }
        div.carousel-inner{
            height: 350px;
        }
div.carousel.slide div.carousel-inner div.carousel-item div.carousel-caption h1{
  
  padding-right: 70px;
   font-family: 'Fira Code';
   font-size: 18px;
}
div.carousel.slide div.carousel-inner div.carousel-item div.carousel-caption h3{
    padding-top: 400px;
   font-family: 'Grenze', serif;
   font-size: 20px;
   margin-top: 300px;
   font-weight: bold;
   letter-spacing: 1px;
   color: lawngreen;
}
div.carousel.slide div.carousel-inner div.carousel-item div.carousel-caption p{
    padding-bottom: 40px;
    font-family: 'Fira Code';
    letter-spacing: normal;
    font-size: 15px;
}
div.carousel-caption h2{
   font-weight: bold;
   font-size: 30px;
}
div.carousel.slide ul.carousel-indicators{
    padding-bottom: 0px;
    padding-top: 2000px;
}
        .col-sm-9,.col-sm-3{
            padding-top: 10px;
            font-family: 'Grenze', serif;
        }
        .col-sm-5{padding-right:0px;}
        footer{padding-top:50px; padding-right:0px; padding-left:0px;margin: 0 11px;} 
        footer .col-sm-12{
            padding: 0;
            margin: 0;
        }
        
.col-sm-12.box{
  margin-top: 0px;
}
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:10px;
        }
        .container.top span.float{
          float:right;
          font-size: 18px;
        }          
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 10;
    color: aliceblue;
    font-size: 12px;
    
}
.fa-instagram{
    font: 10;
    color: aliceblue;
    font-size: 12px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 10;
    font-size: 12px;
    color: aliceblue;
}

      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 15px;
      }
    h2.top{
      font-size: 29px;
    }  
    p.top{
      font-size: 15px;
    }
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: #454242;
    padding-bottom: 0px;
    margin-top:0;
    padding-top: 50px;
}
.container{
    box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
    color: #454242;
    background:#fefdfd;
    padding: 0;
    margin: 0;
    width: 100%;

}
  .col-sm-6.last{
      margin-left: 0;
      padding-left: 0;
  }
  .col-sm-6.first .panel-default{
    margin-left:0px;
    padding-left: 0;
    margin-bottom: 0;
    padding-bottom: 0;
  }
  .col-sm-6.first{
      margin-right: 0;
      padding-right: 0;
      margin-left: 0;
      padding-left: 0;
  }
  .row.help .panel-default .panel-body{
    background: rgb(240, 243, 245);
     color: green;
      height: 350px;
      margin-right: 0;
      width: 300px;
      margin-bottom: 0px;
      margin-left: 20px;
  }
  .row.help .panel-default .panel-body.img{
            background:url('img/help.webp') no-repeat;
            background-size: cover;
            margin-left: 0;
            margin-left: 20px;
            background-position: center;
  }
}
</style>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
<div class="jumbotron">
    
    <h2 class="text-center top" style="color:#454242;">
      Murphy Charitable Foundation
    </h2>
  <p class="text-center top" style="color:#666464;">
      Changing the world one donation at a time.
  </p>
  </div><!---end div for jumbotron---->
  <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <hr>
  <!---div for slide---->
  <div class="row">
    <div id="demo" class="carousel slide carousel-fade" data-ride="carousel">
     
          
          <!-- Indicators--> 
          <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            <li data-target="#demo" data-slide-to="3"></li>
          </ul>
        
          <!-- The slideshow -->
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="<?php echo e(URL::asset('img/17.jpeg')); ?>" alt="farm" style="">
              <div class="carousel-caption">
                <h3 class="text-justify">Murphy Charitable Foundation</h3>
                <h1 class="text-justify"style="color:#E3E2E2;">
                  Murphy Charitable Foundation.
                </h1>
                <p>Give,Help,Receive....</p>
            </div>
            </div>
            <div class="carousel-item">
              <img src="<?php echo e(URL::asset('img/use2.jpg')); ?>" alt="farm" style="">
              <div class="carousel-caption">
                <h3 class="text-justify">Murphy Charitable Foundation</h3>
                <h1 class="text-justify" style="color:#E3E2E2;">
                  Murphy Charitable Foundation
                </h1>
                <p>Promoting good values,Helping the needy,Putting smile peoples face...</p>
            </div>
            </div>
            <div class="carousel-item">
              <img src="<?php echo e(URL::asset('img/use2.jpg')); ?>" alt="farm" style="">
              <div class="carousel-caption">
                <h3 class="text-justify">Murphy Charitable Foundation</h3>
                <h1 class="text-justify" style="color:#E3E2E2;">
                  Murphy Charitable Foundation
                </h1>
                <p>Promoting good values,Helping the needy,Putting smile peoples face...</p>
            </div>
            </div>
            
            <div class="carousel-item">
              <img src="<?php echo e(URL::asset('img/use3.jpg')); ?>" alt="farm" style="">
              <div class="carousel-caption">
                <h3 class="text-justify">Murphy Charitable Foundation</h3>
                <h1 class="text-justify" style="color:#E3E2E2;">
                  Murphy Charitable Foundation
                </h1>
                <p>Promoting good values,Helping the needy,Putting smile peoples face...</p>
            </div>
            </div>

          </div>
        
          <!-- Left and right controls 
          <a class="carousel-control-prev" href="#demo" data-slide="prev">
            <span class="carousel-control-prev-icon"></span>
          </a>
          <a class="carousel-control-next" href="#demo" data-slide="next">
            <span class="carousel-control-next-icon"></span>
          </a>-->
      </div><!---end div for slide---->
    </div><!---end div for slide row---->
    <!---div for who we are---->
<div class="col-sm-12 box"style="color:#666464;">
   <div class="box">
    <h3 class="text-justify" style="line-height:1.8em; font-size:3em;color:#454242;">Who We Are</h3>
    <p>
        Inspired by a life-changing event, Murphy Charitable Foundation was established in 2018 in South Africa (Africa, SA). Over the years, we have become one of the most trusted and effective charitable foundations as we are guided by our Father God, Over the years we have seen too much pain and heartache . Here you can learn more about who we are and what we do, what we need assistance with.
    </p>
   </div>
      <div class="box" style="color:#666464;">
        <h3 class="text-justify" style="line-height:1.8em; font-size:3em;color:#454242;">What We Do</h3>
        <p style="padding-top:0px; padding-right:0px; padding-left:0px; text-align:justify;color:#666464;">
                <li style="text-align:justify; list-style:none;color:#666464;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>To address gender issues and empower women socially, economically and politically.</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>To promote value based education and rights among children, youths, adults at family and community levels for universal development</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>To increase awareness about health, sanitation and hygiene in general, STDs and HIV/AIDS in particular.</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>To promote peace, Interfaith dialogue and bring Sustainable relief services to Internally Displaced persons and disadvantaged persons caused by natural disasters, wars and other pandemics</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>To alleviate poverty and strengthen livelihood of the poor and underprivileged communities through promoting sustainable agriculture, climate smart crops, entrepreneurship and agripreneurship, thereby ensuring food security, food sovereignty, nutritional security and income security</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>To address and reduce ecological degradation through, conservation of biodiversity, waste management, promotion of renewable energy and, enhancing local climate adaptation methods through mass awareness campaigns, advocacy and research and , plantations of forest species</li> 
                
          </p>
         <a href="contact" class="btn btn-success btn-lg">Get In Touch</a>
      </div>
    </div><!---end div for who we are col-sm-12---->
    <div class="col-sm-12"style="color:#666464;">
        <!---div for gallery---->
     <div class="row gallery">
        <div class="container gallery">
        <div class="mySlides">
          <img src="img/use2.jpg" style="width:100%">
        </div>
      
        <div class="mySlides">
          <img src="img/use5.jpg" style="width:100%">
        </div>
      
        <div class="mySlides">
          <img src="img/use4.jpg" style="width:100%">
        </div>
          
        <div class="mySlides">
          <img src="img/4.jpg" style="width:100%">
        </div>
      
        <div class="mySlides">
          <img src="img/17.jpeg" style="width:100%">
        </div>
          
        <div class="mySlides">
          <img src="img/use6.jpg" style="width:100%">
        </div>
        <div class="mySlides">
          <img src="img/15.jpeg" style="width:100%">
        </div>
      
        <div class="mySlides">
          <img src="img/8.jpeg" style="width:100%">
        </div>
      
        <div class="mySlides">
          <img src="img/use1.jpg" style="width:100%">
        </div>
          
        <div class="mySlides">
          <img src="img/10.jpeg" style="width:100%">
        </div>
      
        <div class="mySlides">
          <img src="img/11.jpeg" style="width:100%">
        </div>
          
        <div class="mySlides">
          <img src="img/12.jpeg" style="width:100%">
        </div>
        <div class="caption-container">
          <p id="caption"></p>
        </div>
      
        <div class="row bottom">
          <div class="column">
            <img class="demo cursor" src="img/use2.jpg" style="width:100%" onclick="currentSlide(1)" alt="Title 1">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/use5.jpg" style="width:100%" onclick="currentSlide(2)" alt="Title 2">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/use4.jpg" style="width:100%" onclick="currentSlide(3)" alt="Title 3">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/4.jpg" style="width:100%" onclick="currentSlide(4)" alt="Title 4">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/17.jpeg" style="width:100%" onclick="currentSlide(5)" alt="Title 5">
          </div>    
          <div class="column">
            <img class="demo cursor" src="img/use6.jpg" style="width:100%" onclick="currentSlide(6)" alt="Title 6">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/15.jpeg" style="width:100%" onclick="currentSlide(7)" alt="Title 7">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/8.jpeg" style="width:100%" onclick="currentSlide(8)" alt="Title 8">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/use1.jpg" style="width:100%" onclick="currentSlide(9)" alt="Title 9">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/10.jpeg" style="width:100%" onclick="currentSlide(10)" alt="Title 10">
          </div>
          <div class="column">
            <img class="demo cursor" src="img/11.jpeg" style="width:100%" onclick="currentSlide(11)" alt="Title 11">
          </div>    
          <div class="column">
            <img class="demo cursor" src="img/12.jpeg" style="width:100%" onclick="currentSlide(12)" alt="Title 12">
          </div>
        </div>
      </div><!---end div for gallery container---->
      
</div><!---end div for gallery row---->
</div><!---end div for gwho we are col-sm-12---->
<p style="color:#666464;">
        Seeds of change planted, change in life is better seen in action, not words spoken.
      The change will be seen in our works and in what we create in possitive actiions.
     
</p>
<p> <a href="" class="btn btn-success btn-md">Donate</a></p>
<h2 class="text-justify" style="color:#454242;">How We Help</h2>
<p style="color:#666464;">It Starts With the Will to Make a Difference.</p>
<!---div for act---->
<div class="row act" style="color:#666464;">
    
        <div class="col-sm-4 text-center">
                <div class="panel-group">
                   <div class="panel-default habitat first">
                      <div class="panel-body">
                          <p><i class="fa fa-quote-left"></i><i class="fa fa-quote-right"></i></p>
                        <h4>
                                Abundance of life.
                        </h4>
                    </div>
                    </div>
                </div>
              </div>
              <div class="col-sm-4 text-center">
                      <div class="panel-group">
                         <div class="panel-default bd">
                            <div class="panel-body">
                                    <p><i class="fa fa-pied-piper-alt"></i></p>
                              <h4>
                                    Life changing and making a difference.
                             </h4>
                                </div>
                          </div>
                      </div>
                    </div>
                    <div class="col-sm-4 text-center">
                          <div class="panel-group">
                             <div class="panel-default A-for last">
                                <div class="panel-body">
                                        <p><i class="fa fa-paw"></i></p>   
                                  <h4>
                                        Donations & assistance.
                                  </h4>
                                </div>
                              </div>
                          </div>
                    </div>
</div><!---end div for act---->

    <div class="row help">
            <div class="col-sm-6 first">
                
                <div class="panel-group">
                  <div class="panel-default">
                     <div class="panel-body" style="padding:50px;">  
                        <h5 style="padding-top:50px;">
                                "Act as if what you do makes a difference. It does"
                        </h5>
                        <p style="padding-top:20px;">William James</p>
                     </div>
                  </div>
                </div>
            </div>
             <div class="col-sm-6 last">
                    <div class="panel-group">
                        <div class="panel-default" style="margin-left:0px;">
                               <div class="panel-body img">
                               </div>
                       </div>
                   </div>
               </div>
    </div>
</div>
</div><!---end div for container---->
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="../../vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'article-ckeditor');
</script>
      <script>
      var slideIndex = 1;
      showSlides(slideIndex);
      
      function plusSlides(n) {
        showSlides(slideIndex += n);
      }
      
      function currentSlide(n) {
        showSlides(slideIndex = n);
      }
      
      function showSlides(n) {
        var i;
        var slides = document.getElementsByClassName("mySlides");
        var dots = document.getElementsByClassName("demo");
        var captionText = document.getElementById("caption");
        if (n > slides.length) {slideIndex = 1}
        if (n < 1) {slideIndex = slides.length}
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        for (i = 0; i < dots.length; i++) {
            dots[i].className = dots[i].className.replace(" active", "");
        }
        slides[slideIndex-1].style.display = "block";
        dots[slideIndex-1].className += " active";
        captionText.innerHTML = dots[slideIndex-1].alt;
      }
      </script>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/pages/home.blade.php ENDPATH**/ ?>