<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    
    public function index(){
        return view('pages.home');//here i can return any page i want.
    }
    public function contact(){
        return view('pages.contact');//here i can return any page i want.
    }
    public function about(){
        return view('pages.about');//here i can return any page i want.
    }
    public function donate(){
        return view('pages.donate');//here i can return any page i want.
    }
    public function newsletter(){
        return view('pages.newsletter');//here i can return any page i want.
    }
    public function volunteer(){
        return view('pages.volunteer');//here i can return any page i want.
    }
    public function sponsor(){
        return view('pages.sponsor');//here i can return any page i want.
    }
    public function partner(){
        return view('pages.partner');//here i can return any page i want.
    }
}