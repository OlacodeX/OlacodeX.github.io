<style>

body{
            margin: 0;
            padding: 0;
            background:linear-gradient(rgba(0, 0, 0, 0.995),rgba(8, 8, 8, 0.863)),url('img/sus1.webp') no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            overflow-x: hidden;
            height: 100%;
            width: 100%;
            color: antiquewhite;
            font-family: 'Grenze', serif;
        }
        
        .btn.btn-success{
            
            color:#454242;
            border-radius: 25px;
            background: transparent;
            margin-bottom: 100px;
        }
        #myBtn {
                    display: none;
                    position: fixed;
                    bottom: 20px;
                    right: 30px;
                    z-index: 99;
                    font-size: 18px;
                    border: none;
                    outline: none;
                    color: white;
                    cursor: pointer;
                    padding: 15px;
                    border-radius: 4px;
                }
                
                #myBtn:hover {
                    background-color: #555;
                }
   a{
        text-decoration: none;
     }   
     .row.act .col-sm-4 .panel-body p{
        font-size:16px;
     }
.row.act .col-sm-4 .panel-body{
      border: none;
      background:#000;
      padding-bottom: 30px;
      height: 380px;
      color: antiquewhite;
  }
  .row.act .col-sm-4 .panel-default{
      border: none;
      width: 370px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }
.row.act .col-sm-4 .panel-default.bd .panel-body{
    background: rgb(240, 243, 245);
     color: green;
     background-size: cover;
     background-position: center;
  }
  .row.act .col-sm-4 .panel-default.habitat .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act .col-sm-4 .panel-default.A-for .panel-body{
    background: rgb(240, 243, 245);
     color: green;
  }
  .row.act{
     padding-right: 20px;

  }        
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 100;
    color: aliceblue;
    font-size: 15px;
    
}
.fa-instagram{
    font: 100;
    color: aliceblue;
    font-size: 15px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}

.fa-github{
    color: rgb(0, 0, 0);
    font: 100;
    font-size: 15px;
    color: aliceblue;
}
      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 25px;
      }
       
       
nav.navbar-default{
    padding:0; margin:0;
    background-color: transparent;
    border: none;
}
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 20px;
    margin-top:0;
}
.jumbotron h1{
    color: antiquewhite;
    font-weight: bolder;
}
footer{
        background-color:rgb(26, 26, 26);
        margin:0 36px;
        color: aliceblue;
        padding-top:20px;
        padding-right:20px; 
        padding-left:30px;
    }
    footer h3{
        font-size: 18px;
    }
    footer p{
        color:  rgb(141, 139, 139);
    }
      
.container{
    box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
    color: #454242;
    background:#fefdfd;

}
        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:15px;
          color: aliceblue;
        }
        .container.top span.float{
          float:right;
        }
@media  only screen and (max-width: 768px) {
  /* For mobile phones: */
 
        footer{padding-top:50px; padding-right:0px; padding-left:0px;margin: 0 11px;} 
        footer .col-sm-12{
            padding: 0;
            margin: 0;
        }
        .row.act .col-sm-4 .panel-default{
      border: none;
      width: 310px;
      padding-bottom:20px;
      padding-top: 20px;
     background: transparent;
     box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
  }

        .container.top{
          background-color:green; 
          margin-bottom:0;
          padding-bottom:5px;
          padding-top:10px;
        }
        .container.top span.float{
          float:right;
          font-size: 18px;
        }          
.fa{
    
    padding: 4px;
    padding-top: 0;
    padding-bottom: 0;
}
.fa-twitter{
    color: rgb(48, 206, 206);
    font: 10;
    color: aliceblue;
    font-size: 12px;
    
}
.fa-instagram{
    font: 10;
    color: aliceblue;
    font-size: 12px;
}
.fa-facebook{
    color: rgb(36, 36, 206);
    font: 10;
    font-size: 12px;
    color: aliceblue;
}

      .fa-facebook:hover,
      .fa-instagram:hover,
      .fa-twitter:hover{
        
          font: 200;
          font-size: 15px;
      }
  .row.act{
     padding-right: 20px;
     padding-left: 20px;

  } 
  span.stelar{
      font-size: 13px;
  }  
    h2.top{
      font-size: 29px;
    }  
    p.top{
      font-size: 15px;
    }
div.jumbotron{
    background-color: transparent;
    margin-bottom: 0;
    color: antiquewhite;
    padding-bottom: 0px;
    margin-top:0;
    padding-top: 50px;
}
.container{
    box-shadow: 0 10px 12px 0 rgba(0, 0, 0, 0.2);
    color: #454242;
    background:#fefdfd;
    padding: 0;
    margin: 0;
    width: 100%;

}


}
</style>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">
        <div class="jumbotron">
            
            <h2 class="text-center top"style="color:#454242;">
              Murphy Charitable Foundation
            </h2>
          <p class="text-center top"style="color:#666464;">
              Changing the world one donation at a time.
          </p>
          </div><!---end div for jumbotron---->
          <?php echo $__env->make('inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-justify">
                <h3 style="color:#454242;"><strong>Our Journey So Far</strong></h3>
                <p> 
                    Since been founded, Murphy Foundation has impacted so many lives and engaged in 
                    various community development programs.    
                </p><br>
                <h4 style="color:#454242; font-weight:bold;">
                    Some of these programs include
                </h4>
                <p style="padding-top:0px; padding-right:0px; padding-left:0px; text-align:justify;">
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Supported vulnerable children in region more so orphans to attain free basic education.</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Transformed communities through outreaches to educate, counsel and donate materials like clothes,food, soap,scholastic requirements, pads and pants to the vulnerable ongoing school girls.</li>
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Improved health and sanitation in the communities through community awareness and support for the needy ill person's get better medication in the hospital.</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Supported poor families striked by hunger with relief and aid.</li> 
                <li style="text-align:justify; list-style:none;"><i class="fa fa-bookmark" style="color:green;padding-right:20px;"></i>Reduced rate of child abuse and neglect to 20% in the communities through educating the general public in radio and TV talk shows.</li> 
                </p>
                
            </div>
            <div class="col-sm-12">
                <br><br>
                    <h4 class="text-justify" style="color:#454242;font-weight:bold;">DONATE NOW</h4>
                    <h5>Your generous donations will go a long way in helping us continue this work of creating a better community in our locality. <br><i>Join Us In Impacting Lives And Salvaging Destinies Through Your Generous Donations... <br>
                
                    </i></h5>
                    <p>You can send us your donations through any of the following means.</p>
            </div>
                  
    <!---div for act---->
    <div class="row act">
    
        <div class="col-sm-4 text-center">
                <div class="panel-group">
                   <div class="panel-default habitat first">
                        <div class="panel-body">
                                <h4 class="titles text-center">CRYPTOCURRENCY</h4>      
                            <p style="text-transform:capitalize; padding-top:10px; padding-right:0px; padding-left:0px;">
                                <b>Below are our crypto accounts</b>
                                <br><i>bitcoin: <br>12rVturH7M7Wfr8kukoRv2AYKVpeFuQup3</i>
                                <br><i>Eutherium: <br> 0xE9c8898fF3e292Bf1d90A01DeE5a7cC90fA9411d</i>
                                <br><i>Bitcoin cash: <br> qr7ax0rzmx6hw5flsk4c43x2kljxfayn9slwdgz76l</i>
                                <br><i style="text-transform:lowercase;">Stellar: <br><span class="stelar">GBGZCBLV2UQACNDD4DK467Z7JJM3LS5RPJCFYP5NC72YR3LOVCX7CNLQ</span></i>
                            </p>
                          </div>
                    </div>
                </div>
              </div>
              <div class="col-sm-4 text-center">
                      <div class="panel-group">
                         <div class="panel-default bd">
                                <div class="panel-body">
                                         
                                        <h4 class="titles">ONLINE PAYMENT</h4>        
                                      <p style="padding-top:30px; padding-right:30px; padding-left:30px;">
                                        To pay through our online gateway please click the donate here button or donate through paypal.
                                            
                                      </p>
                                      <a href="" class="btn btn-default btn-md" style="border:1px green solid;color:#555;">DONATE HERE</a>
                                      <a href="PayPal.Me/murphycharity" class="btn btn-default" style="border:1px green solid;color:#555;">
                                        <i class="fa fa-paypal" style="font-style:italic;"></i>USE PAYPAL
                                    </a>
                                  <br><br><p>
                                            <i><b>For Epayswift payment use the email below:</b></i><br> Murphycharity.info@gmail.com
                                           
                                      </p>
                                </div>
                          </div>
                      </div>
                    </div>
                    <div class="col-sm-4 text-center">
                          <div class="panel-group">
                             <div class="panel-default A-for last">
                                    <div class="panel-body">
                                                
                                    <h4 class="titles">CHEQUE DRAFT</h4>   
                                      <p style="padding-top:30px; padding-right:30px; padding-left:30px;">
                                        Please kindly forward cheque to:
                                        Plot 12, Outeke road, Bukedea District, Uganda.
                                     </p>
                                    </div>
                              </div>
                          </div>
                    </div>
     </div><!---end div for act---->
        </div>
    </div>
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\murphyfoundation\resources\views/pages/donate.blade.php ENDPATH**/ ?>