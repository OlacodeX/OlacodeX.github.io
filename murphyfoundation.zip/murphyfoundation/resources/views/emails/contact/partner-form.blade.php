@component('mail::message')
# Hello Murphy Foundation,
# You have received the following request.


 <p>My name is <strong>{{ $data['name']}}</strong> from <strong>{{ $data['country'] }}.</strong></p>
 <p>I am moved and impressed by your good works and I wish to become your partner.
     <br>
     Below are my contact details, do stay in touch.
 </p>
<p><strong>Email:</strong> {{ $data['email']}}</p>
<p><strong>Phone Number:</strong> {{ $data['number']}}</p>

<br><br>
<p>Warm Regards,</p>
<p>MurphyFoundation.</p>
@endcomponent
