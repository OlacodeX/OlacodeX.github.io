<style>
label{
    font-family: 'Supermercado One', cursive;
}
div.container.create{
    margin-top:50px; 
    padding-bottom:100px;
    width:70%;
}
h1.create{
    margin-bottom: 50px;
}
</style>
<?php $__env->startSection('content'); ?>
<div class="container create">
    <h1 class="create">Upload Article</h1>
    <!---If file upload is involved always add enctype to your opening
        form tag and set it to multipart/form-data--->
   <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) /** The action should be the block of code in the store function in PostsController
   **/; ?>

    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        <?php echo e(Form::label('title', 'Title')); ?>

        <!--This is the input field with type=text, name=title, value='' since it is a text field, then bootstrap class and then placeholder--->
        <?php echo e(Form::text('title', '', [ 'class' => 'form-control', 'placeholder' => 'Article title'])); ?>

    </div>
    
    <div class="form-group">
            <?php echo e(Form::label('cover image', 'Cover Image')); ?>

           <?php echo e(Form::file('cover_image', ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        <?php echo e(Form::label('body', 'Body')); ?>

        <!--This is the input field with type=textarea, name=body, value='' since it is a text field, then bootstrap class and then placeholder--->
        <?php echo e(Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => 'Article body'])); ?>

    </div>
    <?php echo e(Form::submit('Upload Article', ['class' => 'btn btn-success btn-md pull-left', 'style' => 'text-transform:uppercase;'])); ?>

   <?php echo Form::close(); ?>

   <a href="../dashboard" class="btn btn-primary btn-md pull-right">Dashboard</a>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StPaul\resources\views/posts/create.blade.php ENDPATH**/ ?>