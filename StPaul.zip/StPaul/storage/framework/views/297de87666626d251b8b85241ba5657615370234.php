<style>
        label{
            font-family: 'Supermercado One', cursive;
        }
        

</style>
<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:150px; padding-bottom:100px;width:70%;">
    <h1>Edit Article</h1>
   <?php echo Form::open(['action' => ['PostsController@update', $post->id]/**the id tells it the post to update*/, 'method' => 'POST',  'enctype' => 'multipart/form-data']) /** The action should be the block of code in the store function in PostsController
   **/; ?>

    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        <?php echo e(Form::label('title', 'Title')); ?>

        <!--This is the input field with type=text, name=title, value=the title from db, then bootstrap class and then placeholder--->
        <?php echo e(Form::text('title', $post->title, [ 'class' => 'form-control', 'placeholder' => 'Article title'])); ?>

    </div>
    
    <div class="form-group">
            <?php echo e(Form::label('cover image', 'Cover Image')); ?>

           <?php echo e(Form::file('cover_image', ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group">
            <!--This is the lable for the field. The first parameter is the lable for, while the second is the name it will carry--->
        <?php echo e(Form::label('body', 'Body')); ?>

        <!--This is the input field with type=textarea, name=body, value='' since it is a text field, then bootstrap class and then placeholder--->
        <?php echo e(Form::textarea('body', $post->body, ['class' => 'form-control', 'placeholder' => 'Research Summary/Abstract'])); ?>

    </div>
    <!---To update in laravel the form method must be PUT but we can have that in normal form tag
        So we create the hidden type below--->
    <?php echo e(Form::hidden('_method', 'PUT')); ?>

    <?php echo e(Form::submit('Update Article', ['class' => 'btn btn-success btn-md pull-left', 'style' => 'text-transform:uppercase;'])); ?>

   <?php echo Form::close(); ?>

<p class="pull-right edit">
    <a href="../../posts" class="btn btn-success btn-md">Blog</a>
    <a href="../../dashboard" class="btn btn-primary btn-md">Dashboard</a>

</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\StPaul\resources\views/posts/edit.blade.php ENDPATH**/ ?>